export interface CodeFile {
  name: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export const CODE_FILES: CodeFile[] = [
  {
    name: 'models.py',
    path: 'backend/models.py',
    language: 'python',
    description: 'SQLAlchemy ORM models: Product, ProductVariant (+560 brand price modifier), Plan (daily/weekly/monthly/yearly lifecycle flags), and SQLite foreign keys.',
    content: `"""
SQLAlchemy ORM Models for Brightloop Software Catalog and Plan Management.

Entities:
- Product: Base subscription entity with sales and cost prices, add-on flag, and soft-delete status.
- ProductVariant: Brand and specification variants with price modifiers (e.g., +560 for premium brand choice).
- Plan: Billing cadence, quantity constraints, availability window, and lifecycle rules.
"""

from datetime import datetime, timezone
import enum
from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Enum as SqlEnum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from .database import Base


class BillingFrequency(str, enum.Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"


class Product(Base):
    """
    Core product entity representing either a standalone subscription,
    core service, or modular add-on.
    
    Includes soft-deleting via \`is_active\` to preserve data integrity
    for historical invoices and active subscriber state.
    """
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    type = Column(String(100), nullable=False, default="subscription")  # subscription, service, license, hardware
    sales_price = Column(Float, nullable=False)                         # Base customer-facing price
    cost_price = Column(Float, nullable=False)                          # Internal COGS / vendor unit cost (Restricted to Admins)
    notes = Column(Text, nullable=True)                                 # Internal or descriptive product notes
    
    # Add-on flag: customers can switch this add-on on and off in their subscription life
    is_addon = Column(Boolean, default=False, nullable=False)
    
    # Soft-delete flag: preserves relational integrity for past invoices & subscriptions
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    # Relationships
    variants = relationship(
        "ProductVariant",
        back_populates="product",
        cascade="all, delete-orphan",
        order_by="ProductVariant.id"
    )
    plans = relationship(
        "Plan",
        back_populates="product",
        cascade="all, delete-orphan",
        order_by="Plan.id"
    )


class ProductVariant(Base):
    """
    Product variant entity (e.g., brand choice, hardware spec, tier level).
    
    Variant Pricing Logic:
    Each variant defines a \`price_modifier\` that is applied directly to the product's
    base \`sales_price\`. For example, selecting the 'Brightloop Elite Enterprise' brand
    variant specifies a price_modifier of +560.00, yielding:
        effective_price = product.sales_price + variant.price_modifier
    """
    __tablename__ = "product_variants"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    variant_name = Column(String(255), nullable=False)  # e.g., "White-Label Brand Edition", "Enterprise Spec"
    brand = Column(String(150), nullable=True)          # e.g., "Brightloop Elite", "Partner Brand X"
    
    # Price modifier: added to product.sales_price (e.g., 560.00 for a specific premium brand choice)
    price_modifier = Column(Float, default=0.0, nullable=False)
    
    sku = Column(String(100), nullable=True, unique=True)
    is_active = Column(Boolean, default=True, nullable=False)

    # Relationship
    product = relationship("Product", back_populates="variants")

    @property
    def effective_price(self) -> float:
        """Computes the final variant price applying the modifier to product base price."""
        if self.product:
            return round(self.product.sales_price + self.price_modifier, 2)
        return self.price_modifier


class Plan(Base):
    """
    Subscription plan linked to a product. Dictates billing cadence,
    pricing, quantity commitments, availability window, and lifecycle rules.
    
    Lifecycle Rules:
    - allow_auto_close: Automatically terminate subscription at contract term expiration.
    - allow_early_closure: Permit customer to cancel subscription before scheduled term.
    - allow_pause: Enable customer to temporarily pause subscription billing cycles.
    - allow_renew: Permit automatic renewal and extension upon cycle completion.
    """
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)          # e.g., "Quarterly Pro", "Annual Commitment"
    
    # Frequency: daily, weekly, monthly, or yearly
    billing_frequency = Column(SqlEnum(BillingFrequency), nullable=False, default=BillingFrequency.MONTHLY)
    
    # Recurring plan price (allows override or package pricing)
    price = Column(Float, nullable=False)
    
    # Minimum required quantity (e.g., minimum 5 seats/units)
    minimum_quantity = Column(Integer, default=1, nullable=False)
    
    # Specific date range the plan remains available for new subscribers
    available_from = Column(Date, nullable=True)
    available_until = Column(Date, nullable=True)
    
    # Lifecycle rule boolean flags
    allow_auto_close = Column(Boolean, default=False, nullable=False)   # Term auto-closure flag
    allow_early_closure = Column(Boolean, default=True, nullable=False)  # Early customer cancellation permitted
    allow_pause = Column(Boolean, default=True, nullable=False)          # Customer-initiated billing pause
    allow_renew = Column(Boolean, default=True, nullable=False)          # Auto-renewal enabled

    is_active = Column(Boolean, default=True, nullable=False)

    # Relationship
    product = relationship("Product", back_populates="plans")
`,
  },
  {
    name: 'schemas.py',
    path: 'backend/schemas.py',
    language: 'python',
    description: 'Pydantic schemas with strict filtering of cost_price for customers and full financial audits for admins.',
    content: `"""
Pydantic Schemas for Brightloop Software Catalog and Plan Management.

Key Security & Serialization Design:
1. CustomerProductResponse strictly omits \`cost_price\` and internal margins,
   exposing only public catalog fields and active relationships.
2. AdminProductResponse includes \`cost_price\`, calculated margin percentages,
   and audit timestamps for business operations.
"""

from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field, computed_field

from .models import BillingFrequency


class VariantBase(BaseModel):
    variant_name: str = Field(..., description="Variant title, e.g. 'Brand Edition Alpha'")
    brand: Optional[str] = Field(None, description="Brand name if applicable, e.g. 'Brightloop Elite'")
    price_modifier: float = Field(
        0.0,
        description="Amount added to base product sales price (e.g. +560.00 for premium brand choice)"
    )
    sku: Optional[str] = Field(None, description="Stock keeping unit or variant identifier")
    is_active: bool = Field(True, description="Whether variant is active and selectable")


class VariantCreate(VariantBase):
    product_id: int = Field(..., description="Associated product ID")


class VariantUpdate(BaseModel):
    variant_name: Optional[str] = None
    brand: Optional[str] = None
    price_modifier: Optional[float] = None
    sku: Optional[str] = None
    is_active: Optional[bool] = None


class VariantResponse(VariantBase):
    id: int
    product_id: int

    model_config = ConfigDict(from_attributes=True)


class PlanBase(BaseModel):
    name: str = Field(..., description="Plan title, e.g. 'Enterprise Monthly'")
    billing_frequency: BillingFrequency = Field(
        BillingFrequency.MONTHLY,
        description="Billing cycle cadence: daily, weekly, monthly, or yearly"
    )
    price: float = Field(..., ge=0, description="Recurring price for the billing cycle")
    minimum_quantity: int = Field(1, ge=1, description="Minimum quantity commitment required")
    available_from: Optional[date] = Field(None, description="Start date of plan offering")
    available_until: Optional[date] = Field(None, description="End date / sunset date of plan offering")
    
    allow_auto_close: bool = Field(False, description="Auto-close subscription at end of term")
    allow_early_closure: bool = Field(True, description="Customer early termination permitted")
    allow_pause: bool = Field(True, description="Customer can pause subscription renewals")
    allow_renew: bool = Field(True, description="Auto-renew at period end")
    is_active: bool = Field(True, description="Plan active status")


class PlanCreate(PlanBase):
    product_id: int = Field(..., description="Parent product ID")


class PlanUpdate(BaseModel):
    name: Optional[str] = None
    billing_frequency: Optional[BillingFrequency] = None
    price: Optional[float] = None
    minimum_quantity: Optional[int] = None
    available_from: Optional[date] = None
    available_until: Optional[date] = None
    allow_auto_close: Optional[bool] = None
    allow_early_closure: Optional[bool] = None
    allow_pause: Optional[bool] = None
    allow_renew: Optional[bool] = None
    is_active: Optional[bool] = None


class PlanResponse(PlanBase):
    id: int
    product_id: int

    model_config = ConfigDict(from_attributes=True)


class CustomerProductResponse(BaseModel):
    """
    Public / Customer facing product schema.
    
    SECURITY INVARIANT:
    \`cost_price\` is deliberately omitted from this model and will never be
    serialized in customer responses. Only active variants and plans are exposed.
    """
    id: int
    name: str
    type: str
    sales_price: float
    notes: Optional[str] = None
    is_addon: bool
    variants: List[VariantResponse] = []
    plans: List[PlanResponse] = []

    model_config = ConfigDict(from_attributes=True)


class ProductCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    type: str = Field("subscription", max_length=100)
    sales_price: float = Field(..., ge=0, description="Base sales price to customers")
    cost_price: float = Field(..., ge=0, description="Internal unit/COGS cost price")
    notes: Optional[str] = None
    is_addon: bool = Field(False, description="True if customers can toggle on/off as add-on")
    is_active: bool = Field(True, description="Active status; false represents soft-deleted/archived")


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    sales_price: Optional[float] = None
    cost_price: Optional[float] = None
    notes: Optional[str] = None
    is_addon: Optional[bool] = None
    is_active: Optional[bool] = None


class AdminProductResponse(BaseModel):
    id: int
    name: str
    type: str
    sales_price: float
    cost_price: float
    notes: Optional[str] = None
    is_addon: bool
    is_active: bool
    created_at: datetime
    updated_at: datetime
    variants: List[VariantResponse] = []
    plans: List[PlanResponse] = []

    model_config = ConfigDict(from_attributes=True)

    @computed_field
    @property
    def gross_margin(self) -> float:
        return round(self.sales_price - self.cost_price, 2)

    @computed_field
    @property
    def gross_margin_percent(self) -> float:
        if self.sales_price <= 0:
            return 0.0
        return round(((self.sales_price - self.cost_price) / self.sales_price) * 100, 2)


class ArchiveResponse(BaseModel):
    product_id: int
    name: str
    is_active: bool
    message: str
`,
  },
  {
    name: 'auth.py',
    path: 'backend/auth.py',
    language: 'python',
    description: 'Role-Based Access Control (RBAC) decorators and dependencies for Flask (Admin vs Customer).',
    content: `"""
Role-Based Access Control (RBAC) & Authentication for Flask in Brightloop Software.

Security Architecture:
- Admin Role: Full operational privileges over products, pricing modifiers, lifecycle rules,
  and soft-delete archiving.
- Customer Role: Strictly granted read-only catalog access. This empowers subscribers to
  browse active catalog offerings, evaluate add-ons, and self-manage plan selection
  without submitting support tickets or emailing administrators.
"""

from enum import Enum
from functools import wraps
from typing import List, Optional
from flask import g, jsonify, request
from pydantic import BaseModel


class UserRole(str, Enum):
    ADMIN = "admin"
    CUSTOMER = "customer"


class AuthenticatedUser(BaseModel):
    user_id: str
    email: str
    role: UserRole


MOCK_USERS = {
    "admin-token-brightloop": AuthenticatedUser(
        user_id="usr_admin_001",
        email="operations@brightloop.io",
        role=UserRole.ADMIN
    ),
    "customer-token-subscriber": AuthenticatedUser(
        user_id="usr_cust_882",
        email="subscriber@enterprise-client.com",
        role=UserRole.CUSTOMER
    )
}


def get_current_user_from_request() -> Optional[AuthenticatedUser]:
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return None

    token = auth_header.split(" ", 1)[1].strip()

    if token in MOCK_USERS:
        return MOCK_USERS[token]
    if token.lower() in ("admin", "role_admin"):
        return MOCK_USERS["admin-token-brightloop"]
    if token.lower() in ("customer", "role_customer"):
        return MOCK_USERS["customer-token-subscriber"]

    return None


def require_role(allowed_roles: List[UserRole]):
    """
    Decorator implementing role-based access control for Flask endpoints.
    Enforces HTTP 401 for missing tokens and HTTP 403 for unauthorized roles.
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user = get_current_user_from_request()
            if not user:
                return jsonify({
                    "detail": "Authentication required. Provide a valid Bearer token in the Authorization header."
                }), 401

            if user.role not in allowed_roles:
                return jsonify({
                    "detail": (
                        f"Access forbidden: Insufficient permissions. Endpoint requires "
                        f"'{[r.value for r in allowed_roles]}' privileges, but user role is '{user.role.value}'. "
                        f"Customers are strictly granted read-only access for the catalog."
                    )
                }), 403

            g.current_user = user
            return f(*args, **kwargs)
        return decorated_function
    return decorator


require_admin = require_role([UserRole.ADMIN])
require_customer_or_admin = require_role([UserRole.ADMIN, UserRole.CUSTOMER])
`,
  },
  {
    name: 'catalog.py (Blueprint)',
    path: 'backend/blueprints/catalog.py',
    language: 'python',
    description: 'Flask Blueprint for Customer Catalog (GET /catalog) with Pydantic serialization strictly omitting cost_price.',
    content: `"""
Flask Blueprint: Customer Catalog Router for Brightloop Software.

Provides authenticated subscribers and customers with a read-only view of
active products, brand variants, and subscription plans.

Security Enforcement:
1. Role check ensures caller is an authenticated customer or admin.
2. Filter criteria restricts queries to \`Product.is_active == True\`, guaranteeing
   archived products are completely excluded.
3. Response model \`CustomerProductResponse\` strips \`cost_price\` completely at
   the Pydantic serialization boundary.
"""

from datetime import date
from flask import Blueprint, jsonify, request
from sqlalchemy.orm import joinedload

from ..auth import require_customer_or_admin
from ..database import db_session
from ..models import Product
from ..schemas import CustomerProductResponse

catalog_bp = Blueprint("catalog", __name__, url_prefix="/catalog")


@catalog_bp.route("", methods=["GET"])
@require_customer_or_admin
def get_customer_catalog():
    today = date.today()
    
    is_addon_param = request.args.get("is_addon")
    billing_freq_param = request.args.get("billing_frequency")
    search_param = request.args.get("search")

    query = (
        db_session.query(Product)
        .filter(Product.is_active.is_(True))
        .options(
            joinedload(Product.variants),
            joinedload(Product.plans)
        )
    )

    if is_addon_param is not None:
        is_addon_val = is_addon_param.lower() in ("true", "1")
        query = query.filter(Product.is_addon == is_addon_val)

    if search_param:
        pattern = f"%{search_param.strip()}%"
        query = query.filter(
            (Product.name.ilike(pattern)) | 
            (Product.notes.ilike(pattern))
        )

    products = query.order_by(Product.id.asc()).all()

    filtered_payload = []
    for product in products:
        active_variants = [v for v in product.variants if v.is_active]
        active_plans = [
            p for p in product.plans
            if p.is_active and
            (p.available_from is None or p.available_from <= today) and
            (p.available_until is None or p.available_until >= today)
        ]

        if billing_freq_param:
            active_plans = [
                p for p in active_plans
                if p.billing_frequency.value == billing_freq_param or p.billing_frequency == billing_freq_param
            ]
            if not active_plans:
                continue

        product.variants = active_variants
        product.plans = active_plans

        # Pydantic serializes CustomerProductResponse strictly omitting cost_price
        serialized = CustomerProductResponse.model_validate(product).model_dump()
        filtered_payload.append(serialized)

    return jsonify(filtered_payload), 200
`,
  },
  {
    name: 'admin.py (Blueprint)',
    path: 'backend/blueprints/admin.py',
    language: 'python',
    description: 'Flask Blueprint for Admin CRUD, +560 brand variant modifier endpoint, plan lifecycle flags, and soft-delete archiving service.',
    content: `"""
Flask Blueprint: Admin Product & Plan Management for Brightloop Software.

Features:
1. Full CRUD for Products, Brand Variants, and Plans.
2. Financial transparency: Exposes cost_price and calculates margin performance.
3. Archiving Service (Soft Delete): Toggles \`is_active = False\` on products to
   preserve referential integrity for historical subscriptions, reporting,
   and past invoices without orphan errors.
4. Strict access control: Guarded by \`@require_admin\`.
"""

from flask import Blueprint, jsonify, request
from pydantic import ValidationError
from sqlalchemy.orm import joinedload

from ..auth import require_admin
from ..database import db_session
from ..models import Plan, Product, ProductVariant
from ..schemas import (
    AdminProductResponse,
    ArchiveResponse,
    PlanCreate,
    PlanResponse,
    ProductCreate,
    ProductUpdate,
    VariantCreate,
    VariantResponse,
)

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


@admin_bp.route("/products", methods=["GET"])
@require_admin
def list_admin_products():
    include_archived = request.args.get("include_archived", "true").lower() in ("true", "1")
    query = db_session.query(Product).options(
        joinedload(Product.variants),
        joinedload(Product.plans)
    )
    if not include_archived:
        query = query.filter(Product.is_active.is_(True))

    products = query.order_by(Product.id.asc()).all()
    serialized = [AdminProductResponse.model_validate(p).model_dump() for p in products]
    return jsonify(serialized), 200


@admin_bp.route("/products", methods=["POST"])
@require_admin
def create_product():
    json_data = request.get_json(silent=True) or {}
    try:
        payload = ProductCreate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    new_product = Product(**payload.model_dump())
    db_session.add(new_product)
    db_session.commit()
    db_session.refresh(new_product)

    return jsonify(AdminProductResponse.model_validate(new_product).model_dump()), 201


@admin_bp.route("/products/<int:product_id>", methods=["PUT"])
@require_admin
def update_product(product_id: int):
    product = db_session.query(Product).filter(Product.id == product_id).first()
    if not product:
        return jsonify({"detail": f"Product with id {product_id} not found."}), 404

    json_data = request.get_json(silent=True) or {}
    try:
        payload = ProductUpdate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(product, field, value)

    db_session.commit()
    db_session.refresh(product)
    return jsonify(AdminProductResponse.model_validate(product).model_dump()), 200


@admin_bp.route("/products/<int:product_id>/archive", methods=["DELETE"])
@require_admin
def archive_product(product_id: int):
    """
    Soft-Delete (Archive Service):
    Toggles \`is_active\` to False, ensuring past invoices and customer subscriptions
    remain linked and valid without database cascade errors.
    """
    product = db_session.query(Product).filter(Product.id == product_id).first()
    if not product:
        return jsonify({"detail": f"Product with id {product_id} not found."}), 404

    product.is_active = False
    db_session.commit()

    response = ArchiveResponse(
        product_id=product.id,
        name=product.name,
        is_active=False,
        message="Product successfully archived. Historical subscriptions & invoices remain intact."
    )
    return jsonify(response.model_dump()), 200


@admin_bp.route("/variants", methods=["POST"])
@require_admin
def create_variant():
    """Adds a variant with price_modifier (e.g. +560.00 for brand choice)."""
    json_data = request.get_json(silent=True) or {}
    try:
        payload = VariantCreate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    product = db_session.query(Product).filter(Product.id == payload.product_id).first()
    if not product:
        return jsonify({"detail": f"Product {payload.product_id} not found."}), 404

    variant = ProductVariant(**payload.model_dump())
    db_session.add(variant)
    db_session.commit()
    db_session.refresh(variant)

    return jsonify(VariantResponse.model_validate(variant).model_dump()), 201


@admin_bp.route("/plans", methods=["POST"])
@require_admin
def create_plan():
    """Links subscription plan with cadence and lifecycle flags (auto-close, early closure, pause, renew)."""
    json_data = request.get_json(silent=True) or {}
    try:
        payload = PlanCreate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    plan = Plan(**payload.model_dump())
    db_session.add(plan)
    db_session.commit()
    db_session.refresh(plan)

    return jsonify(PlanResponse.model_validate(plan).model_dump()), 201
`,
  },
  {
    name: 'app.py',
    path: 'backend/app.py',
    language: 'python',
    description: 'Flask application factory with database initialization and blueprint registration.',
    content: `from flask import Flask, jsonify
from .blueprints.admin import admin_bp
from .blueprints.catalog import catalog_bp
from .database import db_session, init_db
from .seed import seed_database


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["JSON_SORT_KEYS"] = False

    init_db()
    seed_database()

    @app.teardown_appcontext
    def shutdown_session(exception=None):
        db_session.remove()

    app.register_blueprint(catalog_bp)
    app.register_blueprint(admin_bp)

    @app.route("/health", methods=["GET"])
    def health_check():
        return jsonify({
            "status": "operational",
            "service": "Brightloop Catalog & Plan Management",
            "framework": "Flask 3.x",
            "database": "SQLite (brightloop.db)"
        }), 200

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
`,
  },
  {
    name: 'test_api.py',
    path: 'backend/test_api.py',
    language: 'python',
    description: 'Flask TestClient automated test suite verifying RBAC, cost_price exclusion, soft delete, and +560 brand modifier.',
    content: `import pytest
from .app import app

ADMIN_HEADERS = {"Authorization": "Bearer admin-token-brightloop"}
CUSTOMER_HEADERS = {"Authorization": "Bearer customer-token-subscriber"}


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_customer_catalog_security(client):
    response = client.get("/catalog", headers=CUSTOMER_HEADERS)
    assert response.status_code == 200
    products = response.get_json()
    for prod in products:
        assert "cost_price" not in prod, "CRITICAL: cost_price leaked!"
        assert "Legacy Billing Connector v1 (Sunset)" not in prod["name"]


def test_rbac_customer_forbidden_from_admin_crud(client):
    payload = {"name": "Test", "type": "subscription", "sales_price": 100, "cost_price": 50}
    response = client.post("/admin/products", json=payload, headers=CUSTOMER_HEADERS)
    assert response.status_code == 403
`,
  },
];
