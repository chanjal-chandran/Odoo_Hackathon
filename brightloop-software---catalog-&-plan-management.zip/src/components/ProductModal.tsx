import React, { useState } from 'react';
import { Product } from '../types/catalog';
import { Lock } from 'lucide-react';

interface ProductModalProps {
  product?: Product;
  isOpen: boolean;
  onClose: () => void;
  onSave: (productData: Partial<Product>) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState(product?.name || '');
  const [type, setType] = useState(product?.type || 'subscription');
  const [salesPrice, setSalesPrice] = useState(product?.sales_price?.toString() || '999.00');
  const [costPrice, setCostPrice] = useState(product?.cost_price?.toString() || '300.00');
  const [notes, setNotes] = useState(product?.notes || '');
  const [isAddon, setIsAddon] = useState(product?.is_addon || false);
  const [isActive, setIsActive] = useState(product ? product.is_active : true);

  const numSales = parseFloat(salesPrice) || 0;
  const numCost = parseFloat(costPrice) || 0;
  const margin = numSales - numCost;
  const marginPct = numSales > 0 ? (margin / numSales) * 100 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      name: name.trim(),
      type: type.trim(),
      sales_price: numSales,
      cost_price: numCost,
      notes: notes.trim() || undefined,
      is_addon: isAddon,
      is_active: isActive,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-xl w-full p-6 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <h3 className="text-lg font-bold text-slate-900">
            {product ? 'Edit Subscription Product' : 'Create New Subscription Product'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Product Title *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Brightloop Unified Subscription Engine"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Product Type *
              </label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="subscription">Subscription Core</option>
                <option value="service">Service / Modular Engine</option>
                <option value="license">License</option>
                <option value="hardware">Hardware Unit</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Add-on Flag (Customer Switchable)
              </label>
              <div className="pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isAddon}
                    onChange={(e) => setIsAddon(e.target.checked)}
                    className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-slate-600">Customers can switch on/off</span>
                </label>
              </div>
            </div>
          </div>

          {/* Pricing Row: Sales Price vs Cost Price */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Base Sales Price ($) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={salesPrice}
                onChange={(e) => setSalesPrice(e.target.value)}
                className="w-full bg-white border border-slate-200 rounded-lg p-2 text-slate-900 font-mono tabular-nums focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <span className="text-[10px] text-slate-500">Customer facing rate</span>
            </div>

            <div>
              <label className="font-semibold text-rose-700 mb-1 flex items-center gap-1">
                <Lock className="w-3 h-3 text-rose-500" />
                Cost Price ($ COGS) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value)}
                className="w-full bg-white border border-rose-200 rounded-lg p-2 text-rose-900 font-mono tabular-nums focus:outline-none focus:ring-1 focus:ring-rose-500"
              />
              <span className="text-[10px] text-rose-600">Restricted to Admins only</span>
            </div>

            <div className="col-span-2 pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-600">
              <span>Calculated Gross Margin:</span>
              <span className="font-mono font-bold text-emerald-700">
                ${margin.toFixed(2)} ({marginPct.toFixed(1)}%)
              </span>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Internal &amp; Descriptive Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Descriptive details, SLA guarantees, or operational context..."
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="pt-2 flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="font-semibold text-slate-700">Active (Visible in Catalog)</span>
            </label>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
              >
                {product ? 'Save Changes' : 'Create Product'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
