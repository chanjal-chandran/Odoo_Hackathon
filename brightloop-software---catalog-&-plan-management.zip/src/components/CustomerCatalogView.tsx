import React, { useState } from 'react';
import { Product, BillingFrequency, ProductVariant, Plan } from '../types/catalog';
import { 
  Check, 
  Search, 
  Sparkles, 
  Calendar, 
  RefreshCw, 
  PauseCircle, 
  XCircle, 
  Layers, 
  Code,
  ShieldCheck,
  Tag,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';

interface CustomerCatalogViewProps {
  products: Product[];
  onOpenApiInspector: (endpoint: string) => void;
}

export const CustomerCatalogView: React.FC<CustomerCatalogViewProps> = ({
  products,
  onOpenApiInspector,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'subscription' | 'addon'>('all');
  const [freqFilter, setFreqFilter] = useState<'all' | BillingFrequency>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Track selected variant per product
  const [selectedVariants, setSelectedVariants] = useState<Record<number, number>>({});
  // Track selected plan per product
  const [selectedPlans, setSelectedPlans] = useState<Record<number, number>>({});
  // Track toggled add-ons
  const [activeAddons, setActiveAddons] = useState<Record<number, boolean>>({ 2: true });
  // Inspection modal state
  const [inspectProduct, setInspectProduct] = useState<Product | null>(null);

  // Filter products: strictly is_active only
  const activeProducts = products.filter((p) => p.is_active);

  const filteredProducts = activeProducts.filter((product) => {
    if (filterType === 'subscription' && product.is_addon) return false;
    if (filterType === 'addon' && !product.is_addon) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = product.name.toLowerCase().includes(q);
      const matchNotes = product.notes?.toLowerCase().includes(q) ?? false;
      if (!matchName && !matchNotes) return false;
    }

    if (freqFilter !== 'all') {
      const hasPlanWithFreq = product.plans.some(
        (p) => p.is_active && p.billing_frequency === freqFilter
      );
      if (!hasPlanWithFreq) return false;
    }

    return true;
  });

  const getEffectiveVariant = (product: Product): ProductVariant | undefined => {
    const selectedVariantId = selectedVariants[product.id];
    if (selectedVariantId) {
      return product.variants.find((v) => v.id === selectedVariantId);
    }
    return product.variants.find((v) => v.is_active);
  };

  const getEffectivePlan = (product: Product): Plan | undefined => {
    const selectedPlanId = selectedPlans[product.id];
    if (selectedPlanId) {
      return product.plans.find((p) => p.id === selectedPlanId);
    }
    return product.plans.find((p) => p.is_active);
  };

  const toggleAddon = (productId: number) => {
    setActiveAddons((prev) => ({
      ...prev,
      [productId]: !prev[productId],
    }));
  };

  return (
    <div className="space-y-6">
      {/* Editorial Title & Context */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs text-indigo-700 font-semibold mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Authenticated Subscriber Catalog (Read-Only)</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-500 font-normal">Pydantic Model: CustomerProductResponse</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Subscription Catalog &amp; Self-Service Add-ons
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Browse available subscription engines and switchable add-ons. 
            Variant brand options and lifecycle rules calculate in real-time. 
            Internal wholesale cost data is filtered by backend access rules.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => onOpenApiInspector('GET /catalog')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <Code className="w-4 h-4 text-slate-600" />
            Inspect GET /catalog Payload
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-lg border border-slate-200">
        {/* Type Segmented Control */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            type="button"
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filterType === 'all'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Items ({activeProducts.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('subscription')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filterType === 'subscription'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Core Subscriptions
          </button>
          <button
            type="button"
            onClick={() => setFilterType('addon')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              filterType === 'addon'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Switchable Add-ons
          </button>
        </div>

        {/* Cadence filter & search */}
        <div className="flex items-center gap-3">
          <select
            value={freqFilter}
            onChange={(e) => setFreqFilter(e.target.value as any)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="all">All Cadences</option>
            <option value="daily">Daily Metered</option>
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="yearly">Yearly Commitment</option>
          </select>

          <div className="relative min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search catalog..."
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-md pl-8 pr-3 py-1.5 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Product Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredProducts.map((product) => {
          const activeVariant = getEffectiveVariant(product);
          const activePlan = getEffectivePlan(product);

          // Calculate effective price: product.sales_price + variant.price_modifier
          const variantModifier = activeVariant ? activeVariant.price_modifier : 0;
          const calculatedPrice = activePlan 
            ? activePlan.price + (activeVariant ? activeVariant.price_modifier : 0)
            : product.sales_price + variantModifier;

          const isAddonActive = activeAddons[product.id] ?? false;

          return (
            <div
              key={product.id}
              className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between space-y-6 hover:border-slate-300 transition-colors"
            >
              <div className="space-y-4">
                {/* Header & Badges */}
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                      <span className="capitalize font-medium text-slate-700">{product.type}</span>
                      <span aria-hidden="true">·</span>
                      {product.is_addon ? (
                        <span className="text-amber-700 font-medium">Modular Customer Add-on</span>
                      ) : (
                        <span className="text-indigo-700 font-medium">Core Platform Tier</span>
                      )}
                    </div>
                    <h2 className="text-xl font-bold text-slate-900">{product.name}</h2>
                    {product.notes && (
                      <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                        {product.notes}
                      </p>
                    )}
                  </div>

                  {product.is_addon && (
                    <button
                      type="button"
                      onClick={() => toggleAddon(product.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 cursor-pointer"
                      style={{
                        backgroundColor: isAddonActive ? '#ecfdf5' : '#f1f5f9',
                        color: isAddonActive ? '#047857' : '#475569',
                      }}
                      title="Customer self-service switch for add-ons"
                    >
                      {isAddonActive ? (
                        <>
                          <ToggleRight className="w-4 h-4 text-emerald-600" />
                          <span>Active on Plan</span>
                        </>
                      ) : (
                        <>
                          <ToggleLeft className="w-4 h-4 text-slate-400" />
                          <span>Add-on Inactive</span>
                        </>
                      )}
                    </button>
                  )}
                </div>

                {/* Relational Variant Selector (e.g. Brand Choice with +560 modifier) */}
                {product.variants.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-slate-400" />
                        Select Brand &amp; Deployment Variant:
                      </span>
                      {activeVariant && activeVariant.price_modifier > 0 && (
                        <span className="text-indigo-600 font-mono text-[11px] font-medium">
                          Brand modifier: +${activeVariant.price_modifier.toFixed(2)}
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-1 gap-2">
                      {product.variants
                        .filter((v) => v.is_active)
                        .map((variant) => {
                          const isSelected = activeVariant?.id === variant.id;
                          return (
                            <button
                              key={variant.id}
                              type="button"
                              onClick={() =>
                                setSelectedVariants((prev) => ({
                                  ...prev,
                                  [product.id]: variant.id,
                                }))
                              }
                              className={`w-full flex items-center justify-between p-2.5 rounded-lg text-left text-xs transition-all border ${
                                isSelected
                                  ? 'border-indigo-600 bg-indigo-50/50 text-slate-900 ring-1 ring-indigo-600'
                                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <div
                                  className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                                    isSelected
                                      ? 'border-indigo-600 bg-indigo-600'
                                      : 'border-slate-300 bg-white'
                                  }`}
                                >
                                  {isSelected && <Check className="w-2.5 h-2.5 text-white" />}
                                </div>
                                <div className="truncate">
                                  <span className="font-semibold text-slate-900">
                                    {variant.brand || variant.variant_name}
                                  </span>
                                  {variant.brand && (
                                    <span className="text-slate-500 ml-1.5">
                                      ({variant.variant_name})
                                    </span>
                                  )}
                                </div>
                              </div>

                              <div className="text-right shrink-0 font-mono tabular-nums text-xs font-semibold ml-2">
                                {variant.price_modifier === 0 ? (
                                  <span className="text-slate-500 font-normal">Base Rate</span>
                                ) : (
                                  <span className="text-indigo-700">
                                    +${variant.price_modifier.toFixed(2)}
                                  </span>
                                )}
                              </div>
                            </button>
                          );
                        })}
                    </div>
                  </div>
                )}

                {/* Available Subscription Plans (Daily, Weekly, Monthly, Yearly) */}
                {product.plans.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-slate-100">
                    <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      Select Billing Cadence &amp; Term:
                    </span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {product.plans
                        .filter((p) => p.is_active)
                        .map((plan) => {
                          const isSelected = activePlan?.id === plan.id;
                          return (
                            <button
                              key={plan.id}
                              type="button"
                              onClick={() =>
                                setSelectedPlans((prev) => ({
                                  ...prev,
                                  [product.id]: plan.id,
                                }))
                              }
                              className={`p-2.5 rounded-lg text-left text-xs transition-all border flex flex-col justify-between ${
                                isSelected
                                  ? 'border-indigo-600 bg-indigo-50/50 ring-1 ring-indigo-600'
                                  : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                              }`}
                            >
                              <div>
                                <div className="flex items-center justify-between gap-1 mb-1">
                                  <span className="font-semibold text-slate-900 truncate">
                                    {plan.name}
                                  </span>
                                  <span className="capitalize text-[10px] px-1.5 py-0.5 rounded bg-slate-200 text-slate-700 font-medium">
                                    {plan.billing_frequency}
                                  </span>
                                </div>
                                <div className="text-[11px] text-slate-500">
                                  Min Qty: {plan.minimum_quantity}
                                </div>
                              </div>

                              <div className="mt-2 pt-1 border-t border-slate-200/60 flex items-center justify-between text-xs font-mono tabular-nums">
                                <span className="text-slate-600">Plan Rate:</span>
                                <span className="font-bold text-slate-900">
                                  ${plan.price.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                </span>
                              </div>
                            </button>
                          );
                        })}
                    </div>
                  </div>
                )}

                {/* Plan Lifecycle Rules Display */}
                {activePlan && (
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
                    <span className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold block">
                      Subscription Lifecycle Rules ({activePlan.name})
                    </span>
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="flex items-center gap-1.5 text-slate-700">
                        {activePlan.allow_renew ? (
                          <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-amber-600" />
                        )}
                        <span>{activePlan.allow_renew ? 'Auto-renews at end of cycle' : 'No automatic renewal'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-700">
                        {activePlan.allow_pause ? (
                          <PauseCircle className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-slate-400" />
                        )}
                        <span>{activePlan.allow_pause ? 'Billing pause allowed' : 'Pause not allowed'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-700">
                        {activePlan.allow_early_closure ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-rose-500" />
                        )}
                        <span>{activePlan.allow_early_closure ? 'Early cancellation permitted' : 'Contract term committed'}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-700">
                        {activePlan.allow_auto_close ? (
                          <Check className="w-3.5 h-3.5 text-amber-600" />
                        ) : (
                          <XCircle className="w-3.5 h-3.5 text-slate-400" />
                        )}
                        <span>{activePlan.allow_auto_close ? 'Auto-closes at term sunset' : 'Continuous subscription'}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Effective Price Calculation & Action */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-slate-500">
                    Effective Customer Rate ({activePlan?.billing_frequency || 'monthly'}):
                  </div>
                  <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums">
                    ${calculatedPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setInspectProduct(product)}
                    className="p-2 text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                    title="Verify customer JSON model excludes cost_price"
                  >
                    <Code className="w-4 h-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      alert(
                        `Subscription order processed for "${product.name}" with variant "${activeVariant?.variant_name}" at $${calculatedPrice.toFixed(2)}.`
                      );
                    }}
                    className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors whitespace-nowrap"
                  >
                    {product.is_addon ? 'Configure Add-on' : 'Subscribe Now'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Security Verification Modal */}
      {inspectProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full p-6 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">
                  Customer Response Schema Serialization Check
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setInspectProduct(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                ✕
              </button>
            </div>

            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-xs text-emerald-800">
              <strong>Security Invariant Confirmed:</strong> Notice that{' '}
              <code className="font-mono bg-emerald-100 px-1 py-0.5 rounded">cost_price</code> is
              strictly excluded by FastAPI's Pydantic response model. The customer sees only public
              sales pricing, active brand variants, and configured subscription plans.
            </div>

            <pre className="p-4 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono overflow-auto max-h-96">
              {JSON.stringify(
                {
                  id: inspectProduct.id,
                  name: inspectProduct.name,
                  type: inspectProduct.type,
                  sales_price: inspectProduct.sales_price,
                  notes: inspectProduct.notes,
                  is_addon: inspectProduct.is_addon,
                  // NOTE: cost_price: [REDACTED BY PYDANTIC]
                  variants: inspectProduct.variants.filter((v) => v.is_active),
                  plans: inspectProduct.plans.filter((p) => p.is_active),
                },
                null,
                2
              )}
            </pre>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setInspectProduct(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
