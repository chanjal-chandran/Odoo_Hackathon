import React, { useState } from 'react';
import { Product, UserRole } from '../types/catalog';
import { 
  Play, 
  ShieldCheck, 
  ShieldAlert, 
  Lock, 
  Send, 
  Code2, 
  CheckCircle2, 
  XCircle, 
  Copy, 
  Check 
} from 'lucide-react';

interface ApiExplorerViewProps {
  products: Product[];
  userRole: UserRole;
  initialEndpoint?: string;
}

interface EndpointDef {
  id: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  title: string;
  tag: 'Customer Catalog' | 'Admin Management';
  requiredRole: 'customer or admin' | 'admin';
  description: string;
  defaultParams?: Record<string, string>;
  defaultBody?: any;
}

const ENDPOINTS: EndpointDef[] = [
  {
    id: 'get_catalog',
    method: 'GET',
    path: '/catalog',
    title: 'Customer Catalog (Read-Only)',
    tag: 'Customer Catalog',
    requiredRole: 'customer or admin',
    description:
      'Returns active products, brand variants, and plans. Strictly omits cost_price and archived products via CustomerProductResponse.',
    defaultParams: {
      is_addon: '',
      billing_frequency: '',
      search: '',
    },
  },
  {
    id: 'get_admin_products',
    method: 'GET',
    path: '/admin/products',
    title: 'List All Products (Admin View)',
    tag: 'Admin Management',
    requiredRole: 'admin',
    description:
      'Returns all products including internal cost prices, gross margins, and archived/soft-deleted records.',
    defaultParams: {
      include_archived: 'true',
    },
  },
  {
    id: 'post_admin_product',
    method: 'POST',
    path: '/admin/products',
    title: 'Create Product (Admin)',
    tag: 'Admin Management',
    requiredRole: 'admin',
    description:
      'Creates a new product with base sales price and restricted wholesale cost price.',
    defaultBody: {
      name: 'Brightloop Multi-Cloud Broker',
      type: 'service',
      sales_price: 850.0,
      cost_price: 240.0,
      notes: 'Automated multi-region data sovereignty gateway',
      is_addon: true,
      is_active: true,
    },
  },
  {
    id: 'post_admin_variant',
    method: 'POST',
    path: '/admin/variants',
    title: 'Create Variant (+560 Modifier)',
    tag: 'Admin Management',
    requiredRole: 'admin',
    description:
      'Adds a variant with a brand choice price modifier (e.g. +$560.00 to base price).',
    defaultBody: {
      product_id: 1,
      variant_name: 'GovSovereign Dedicated Edition',
      brand: 'Brightloop Elite Federal',
      price_modifier: 560.0,
      sku: 'BL-GOV-FED-560',
      is_active: true,
    },
  },
  {
    id: 'post_admin_plan',
    method: 'POST',
    path: '/admin/plans',
    title: 'Create Plan with Lifecycle Flags',
    tag: 'Admin Management',
    requiredRole: 'admin',
    description:
      'Links subscription plan with cadence and lifecycle rules (auto_close, pause, renew).',
    defaultBody: {
      product_id: 1,
      name: 'Biannual Scale Tier',
      billing_frequency: 'monthly',
      price: 1100.0,
      minimum_quantity: 2,
      available_from: '2026-01-01',
      available_until: '2027-12-31',
      allow_auto_close: false,
      allow_early_closure: true,
      allow_pause: true,
      allow_renew: true,
      is_active: true,
    },
  },
  {
    id: 'delete_admin_archive',
    method: 'DELETE',
    path: '/admin/products/1/archive',
    title: 'Soft-Delete (Archive Service)',
    tag: 'Admin Management',
    requiredRole: 'admin',
    description:
      'Toggles is_active=False. Immediately removes from customer catalog while preserving historical invoices.',
  },
];

export const ApiExplorerView: React.FC<ApiExplorerViewProps> = ({
  products,
  userRole,
  initialEndpoint,
}) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<EndpointDef>(
    ENDPOINTS.find((e) => e.path === initialEndpoint) || ENDPOINTS[0]
  );
  const [queryParams, setQueryParams] = useState<Record<string, string>>(
    selectedEndpoint.defaultParams || {}
  );
  const [requestBody, setRequestBody] = useState<string>(
    selectedEndpoint.defaultBody ? JSON.stringify(selectedEndpoint.defaultBody, null, 2) : ''
  );
  const [responseResult, setResponseResult] = useState<{
    status: number;
    statusText: string;
    durationMs: number;
    data: any;
  } | null>(null);
  const [copiedCurl, setCopiedCurl] = useState(false);

  const handleSelectEndpoint = (ep: EndpointDef) => {
    setSelectedEndpoint(ep);
    setQueryParams(ep.defaultParams || {});
    setRequestBody(ep.defaultBody ? JSON.stringify(ep.defaultBody, null, 2) : '');
    setResponseResult(null);
  };

  const getBearerToken = () => {
    if (userRole === 'admin') return 'admin-token-brightloop';
    if (userRole === 'customer') return 'customer-token-subscriber';
    return '';
  };

  const executeSimulatedRequest = () => {
    const startTime = performance.now();

    // 1. Auth check: if unauthenticated
    if (userRole === 'unauthenticated') {
      setTimeout(() => {
        setResponseResult({
          status: 401,
          statusText: 'Unauthorized',
          durationMs: Math.round(performance.now() - startTime + 12),
          data: {
            detail: 'Authentication required. Provide a valid Bearer token in the Authorization header.',
          },
        });
      }, 100);
      return;
    }

    // 2. RBAC check: if customer tries admin endpoint
    if (selectedEndpoint.requiredRole === 'admin' && userRole !== 'admin') {
      setTimeout(() => {
        setResponseResult({
          status: 403,
          statusText: 'Forbidden',
          durationMs: Math.round(performance.now() - startTime + 15),
          data: {
            detail:
              "Access forbidden: Insufficient permissions. Endpoint requires 'admin' privileges, but user role is 'customer'. Customers are strictly granted read-only access for the catalog so they can manage their own subscriptions without having to email anyone.",
          },
        });
      }, 120);
      return;
    }

    // 3. Customer Catalog GET /catalog
    if (selectedEndpoint.id === 'get_catalog') {
      const activeProducts = products.filter((p) => p.is_active);
      const isAddonFilter = queryParams.is_addon;
      const freqFilter = queryParams.billing_frequency;
      const searchFilter = queryParams.search?.toLowerCase();

      let result = activeProducts.filter((p) => {
        if (isAddonFilter === 'true' && !p.is_addon) return false;
        if (isAddonFilter === 'false' && p.is_addon) return false;
        if (searchFilter && !p.name.toLowerCase().includes(searchFilter)) return false;
        if (freqFilter && !p.plans.some((pl) => pl.billing_frequency === freqFilter && pl.is_active))
          return false;
        return true;
      });

      // STRICT PYDANTIC FILTERING: strip cost_price!
      const sanitized = result.map((p) => ({
        id: p.id,
        name: p.name,
        type: p.type,
        sales_price: p.sales_price,
        // Notice: cost_price is strictly omitted!
        notes: p.notes,
        is_addon: p.is_addon,
        variants: p.variants.filter((v) => v.is_active),
        plans: p.plans.filter((pl) => pl.is_active),
      }));

      setTimeout(() => {
        setResponseResult({
          status: 200,
          statusText: 'OK',
          durationMs: Math.round(performance.now() - startTime + 25),
          data: sanitized,
        });
      }, 150);
      return;
    }

    // 4. Admin GET /admin/products
    if (selectedEndpoint.id === 'get_admin_products') {
      const includeArchived = queryParams.include_archived !== 'false';
      const result = products
        .filter((p) => (includeArchived ? true : p.is_active))
        .map((p) => ({
          id: p.id,
          name: p.name,
          type: p.type,
          sales_price: p.sales_price,
          cost_price: p.cost_price, // Exposed to Admins
          gross_margin: Number((p.sales_price - p.cost_price).toFixed(2)),
          gross_margin_percent: Number(
            p.sales_price > 0
              ? (((p.sales_price - p.cost_price) / p.sales_price) * 100).toFixed(2)
              : 0
          ),
          notes: p.notes,
          is_addon: p.is_addon,
          is_active: p.is_active,
          created_at: p.created_at,
          updated_at: p.updated_at,
          variants: p.variants,
          plans: p.plans,
        }));

      setTimeout(() => {
        setResponseResult({
          status: 200,
          statusText: 'OK',
          durationMs: Math.round(performance.now() - startTime + 30),
          data: result,
        });
      }, 160);
      return;
    }

    // 5. Admin POST /admin/products
    if (selectedEndpoint.id === 'post_admin_product') {
      try {
        const body = JSON.parse(requestBody);
        const margin = body.sales_price - body.cost_price;
        const marginPct = body.sales_price > 0 ? (margin / body.sales_price) * 100 : 0;
        const newProduct = {
          id: 99,
          ...body,
          gross_margin: Number(margin.toFixed(2)),
          gross_margin_percent: Number(marginPct.toFixed(2)),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          variants: [],
          plans: [],
        };
        setTimeout(() => {
          setResponseResult({
            status: 201,
            statusText: 'Created',
            durationMs: Math.round(performance.now() - startTime + 40),
            data: newProduct,
          });
        }, 180);
      } catch (err: any) {
        setResponseResult({
          status: 422,
          statusText: 'Unprocessable Entity',
          durationMs: 10,
          data: { detail: 'Invalid JSON request payload.' },
        });
      }
      return;
    }

    // 6. Admin POST /admin/variants
    if (selectedEndpoint.id === 'post_admin_variant') {
      try {
        const body = JSON.parse(requestBody);
        const newVariant = {
          id: 199,
          ...body,
        };
        setTimeout(() => {
          setResponseResult({
            status: 201,
            statusText: 'Created',
            durationMs: Math.round(performance.now() - startTime + 35),
            data: newVariant,
          });
        }, 150);
      } catch (err) {
        setResponseResult({
          status: 422,
          statusText: 'Unprocessable Entity',
          durationMs: 10,
          data: { detail: 'Invalid JSON.' },
        });
      }
      return;
    }

    // 7. Admin POST /admin/plans
    if (selectedEndpoint.id === 'post_admin_plan') {
      try {
        const body = JSON.parse(requestBody);
        const newPlan = {
          id: 299,
          ...body,
        };
        setTimeout(() => {
          setResponseResult({
            status: 201,
            statusText: 'Created',
            durationMs: Math.round(performance.now() - startTime + 35),
            data: newPlan,
          });
        }, 150);
      } catch (err) {
        setResponseResult({
          status: 422,
          statusText: 'Unprocessable Entity',
          durationMs: 10,
          data: { detail: 'Invalid JSON.' },
        });
      }
      return;
    }

    // 8. Admin DELETE /admin/products/1/archive
    if (selectedEndpoint.id === 'delete_admin_archive') {
      setTimeout(() => {
        setResponseResult({
          status: 200,
          statusText: 'OK',
          durationMs: Math.round(performance.now() - startTime + 28),
          data: {
            product_id: 1,
            name: 'Brightloop Unified Subscription Engine',
            is_active: false,
            message:
              'Product successfully archived. Historical subscriptions, invoices, and billing records remain fully intact without foreign key cascade orphans.',
          },
        });
      }, 140);
    }
  };

  const generateCurl = () => {
    const token = getBearerToken();
    let queryStr = '';
    if (queryParams && Object.keys(queryParams).length > 0) {
      const activeParams = Object.entries(queryParams)
        .filter(([_, v]) => v)
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
        .join('&');
      if (activeParams) queryStr = `?${activeParams}`;
    }

    let cmd = `curl -X ${selectedEndpoint.method} "http://127.0.0.1:8000${selectedEndpoint.path}${queryStr}"`;
    if (token) {
      cmd += ` \\\n  -H "Authorization: Bearer ${token}"`;
    }
    if (selectedEndpoint.method === 'POST' || selectedEndpoint.method === 'PUT') {
      cmd += ` \\\n  -H "Content-Type: application/json"`;
      cmd += ` \\\n  -d '${requestBody.replace(/\n\s*/g, ' ')}'`;
    }
    return cmd;
  };

  const copyCurlToClipboard = () => {
    navigator.clipboard.writeText(generateCurl());
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-indigo-700 font-semibold mb-1">
            <Code2 className="w-4 h-4" />
            <span>FastAPI Interactive Endpoint Playground</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-500 font-normal">FastAPI + Pydantic v2 + SQLite</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            API Routing &amp; Dependency Injection Sandbox
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Simulate live HTTP requests to the FastAPI endpoints. Test role-based dependency checks,
            verify that <code className="font-mono text-indigo-700">cost_price</code> is strictly excluded from customer responses,
            and inspect 403 Forbidden responses.
          </p>
        </div>

        <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600 shrink-0">
          <div className="font-semibold text-slate-800">Current Client Identity:</div>
          <div className="font-mono text-indigo-600 mt-0.5">
            Role: <strong className="uppercase">{userRole}</strong>
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Token: {getBearerToken() ? `Bearer ${getBearerToken().slice(0, 16)}...` : 'None (401)'}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Endpoint Directory (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block px-1">
            Available API Endpoints
          </span>

          <div className="space-y-2">
            {ENDPOINTS.map((ep) => {
              const isSelected = selectedEndpoint.id === ep.id;
              const isGet = ep.method === 'GET';
              const isPost = ep.method === 'POST';
              const isDelete = ep.method === 'DELETE';

              return (
                <button
                  key={ep.id}
                  type="button"
                  onClick={() => handleSelectEndpoint(ep)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs space-y-1.5 ${
                    isSelected
                      ? 'border-indigo-600 bg-white ring-2 ring-indigo-600/10 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-mono text-[11px] font-bold px-2 py-0.5 rounded ${
                          isGet
                            ? 'bg-blue-100 text-blue-800'
                            : isPost
                            ? 'bg-emerald-100 text-emerald-800'
                            : isDelete
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {ep.method}
                      </span>
                      <span className="font-semibold text-slate-900">{ep.title}</span>
                    </div>

                    <span className="text-[10px] text-slate-400 shrink-0 font-medium">
                      {ep.requiredRole === 'admin' ? 'Admin only' : 'Public'}
                    </span>
                  </div>

                  <div className="font-mono text-[11px] text-slate-500 truncate">
                    {ep.path}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Request Builder & Response Inspector (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-6">
            {/* Active Endpoint Overview */}
            <div className="space-y-2 pb-4 border-b border-slate-200">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span
                    className={`font-mono text-xs font-bold px-2.5 py-1 rounded ${
                      selectedEndpoint.method === 'GET'
                        ? 'bg-blue-100 text-blue-800'
                        : selectedEndpoint.method === 'POST'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {selectedEndpoint.method}
                  </span>
                  <span className="font-mono font-bold text-slate-900 text-sm">
                    {selectedEndpoint.path}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={executeSimulatedRequest}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-xs"
                >
                  <Send className="w-3.5 h-3.5" />
                  Execute Request
                </button>
              </div>

              <p className="text-xs text-slate-600">{selectedEndpoint.description}</p>
            </div>

            {/* Query Parameters Section if GET */}
            {selectedEndpoint.defaultParams && (
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-800 block">
                  Query Parameters
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {Object.keys(selectedEndpoint.defaultParams).map((paramKey) => (
                    <div key={paramKey}>
                      <label className="block text-[11px] font-mono text-slate-600 mb-1">
                        {paramKey}
                      </label>
                      <input
                        type="text"
                        value={queryParams[paramKey] || ''}
                        onChange={(e) =>
                          setQueryParams({ ...queryParams, [paramKey]: e.target.value })
                        }
                        placeholder={`Optional ${paramKey}...`}
                        className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Request Body if POST/PUT */}
            {(selectedEndpoint.method === 'POST' || selectedEndpoint.method === 'PUT') && (
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-800">
                  JSON Request Body (Pydantic Schema)
                </label>
                <textarea
                  rows={6}
                  value={requestBody}
                  onChange={(e) => setRequestBody(e.target.value)}
                  className="w-full bg-slate-900 text-slate-100 font-mono text-xs rounded-lg p-3 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            )}

            {/* cURL command preview */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-600">Generated cURL Command</span>
                <button
                  type="button"
                  onClick={copyCurlToClipboard}
                  className="flex items-center gap-1 text-[11px] text-indigo-600 hover:text-indigo-800"
                >
                  {copiedCurl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedCurl ? 'Copied' : 'Copy cURL'}
                </button>
              </div>
              <pre className="p-3 bg-slate-950 text-slate-300 rounded-lg text-[11px] font-mono overflow-x-auto whitespace-pre">
                {generateCurl()}
              </pre>
            </div>
          </div>

          {/* Response Inspector Area */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-800">FastAPI Response Output</span>
                {responseResult && (
                  <span
                    className={`font-mono text-xs font-bold px-2 py-0.5 rounded ${
                      responseResult.status < 300
                        ? 'bg-emerald-100 text-emerald-800'
                        : responseResult.status === 403
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    HTTP {responseResult.status} {responseResult.statusText}
                  </span>
                )}
              </div>

              {responseResult && (
                <span className="text-xs text-slate-400 font-mono">
                  {responseResult.durationMs}ms latency
                </span>
              )}
            </div>

            {!responseResult ? (
              <div className="p-8 text-center bg-slate-50 rounded-lg border border-dashed border-slate-200 text-xs text-slate-400">
                Click <strong>"Execute Request"</strong> above to send a request with the current identity{' '}
                (<code className="font-mono">{userRole}</code>) and inspect the FastAPI JSON response.
              </div>
            ) : (
              <div className="space-y-3">
                {/* Specific callouts based on status */}
                {responseResult.status === 200 && selectedEndpoint.id === 'get_catalog' && (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
                    <div>
                      <strong>Pydantic Data Redaction Verified:</strong> Each item in the array below is
                      serialized using <code className="font-mono">CustomerProductResponse</code>. Note that{' '}
                      <code className="font-mono bg-emerald-100 px-1 py-0.5 rounded">cost_price</code> is completely absent,
                      and archived items (like Legacy Billing Connector) are omitted.
                    </div>
                  </div>
                )}

                {responseResult.status === 403 && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2">
                    <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                    <div>
                      <strong>RBAC Dependency Enforcement Verified:</strong> FastAPI dependency{' '}
                      <code className="font-mono bg-rose-100 px-1 py-0.5 rounded">Depends(require_admin)</code>{' '}
                      intercepted this request and blocked execution because the current role is{' '}
                      <code className="font-mono">customer</code>.
                    </div>
                  </div>
                )}

                {responseResult.status === 401 && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-start gap-2">
                    <Lock className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
                    <div>
                      <strong>Authentication Required:</strong> No bearer token was supplied in the Authorization header.
                    </div>
                  </div>
                )}

                <pre className="p-4 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono overflow-auto max-h-[420px] leading-relaxed">
                  {JSON.stringify(responseResult.data, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
