import React from 'react';
import { UserRole } from '../types/catalog';
import { Shield, User, Lock, Layers } from 'lucide-react';

interface NavbarProps {
  activeTab: 'catalog' | 'admin' | 'api' | 'code';
  setActiveTab: (tab: 'catalog' | 'admin' | 'api' | 'code') => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  userRole,
  setUserRole,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single Brand element */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">
              <Layers className="w-4 h-4" />
            </div>
            <a
              href="#catalog"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('catalog');
              }}
              className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap"
            >
              Brightloop Software
            </a>
          </div>

          {/* Zone 2: 4-5 single-line clean navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('catalog')}
              className={`whitespace-nowrap transition-colors pb-1 pt-1 ${
                activeTab === 'catalog'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              Customer Catalog
            </button>
            <button
              onClick={() => setActiveTab('admin')}
              className={`whitespace-nowrap transition-colors pb-1 pt-1 ${
                activeTab === 'admin'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              Admin Management
            </button>
            <button
              onClick={() => setActiveTab('api')}
              className={`whitespace-nowrap transition-colors pb-1 pt-1 ${
                activeTab === 'api'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              FastAPI Sandbox
            </button>
            <button
              onClick={() => setActiveTab('code')}
              className={`whitespace-nowrap transition-colors pb-1 pt-1 ${
                activeTab === 'code'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              Python Codebase
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action (RBAC Role Switcher) */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setUserRole('customer')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                  userRole === 'customer'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Simulate authenticated subscriber view (read-only, cost_price stripped)"
              >
                <User className="w-3.5 h-3.5 text-slate-500" />
                Customer
              </button>
              <button
                type="button"
                onClick={() => setUserRole('admin')}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                  userRole === 'admin'
                    ? 'bg-white text-indigo-700 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Simulate operations administrator (full CRUD, soft delete, cost_price visible)"
              >
                <Shield className="w-3.5 h-3.5 text-amber-600" />
                Admin
              </button>
              <button
                type="button"
                onClick={() => setUserRole('unauthenticated')}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
                  userRole === 'unauthenticated'
                    ? 'bg-white text-red-600 shadow-sm'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
                title="Simulate unauthenticated user (401 Unauthorized)"
              >
                <Lock className="w-3 h-3 text-red-500" />
                Guest
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
