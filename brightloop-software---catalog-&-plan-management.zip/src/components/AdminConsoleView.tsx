import React, { useState } from 'react';
import { Product, ProductVariant, Plan, UserRole } from '../types/catalog';
import { 
  Plus, 
  Archive, 
  RotateCcw, 
  Edit3, 
  Tag, 
  Calendar, 
  ShieldAlert, 
  CheckCircle2, 
  Lock, 
  Search,
  Eye,
  Layers,
  Sparkles,
  TrendingUp,
  FileText
} from 'lucide-react';

interface AdminConsoleViewProps {
  products: Product[];
  userRole: UserRole;
  onOpenProductModal: (product?: Product) => void;
  onOpenVariantModal: (product: Product, variant?: ProductVariant) => void;
  onOpenPlanModal: (product: Product, plan?: Plan) => void;
  onArchiveProduct: (productId: number) => void;
  onRestoreProduct: (productId: number) => void;
  onForbiddenAttempt: (action: string) => void;
}

export const AdminConsoleView: React.FC<AdminConsoleViewProps> = ({
  products,
  userRole,
  onOpenProductModal,
  onOpenVariantModal,
  onOpenPlanModal,
  onArchiveProduct,
  onRestoreProduct,
  onForbiddenAttempt,
}) => {
  const [showArchived, setShowArchived] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedProductId, setExpandedProductId] = useState<number | null>(1);
  const [archiveModalTarget, setArchiveModalTarget] = useState<Product | null>(null);

  const isAdmin = userRole === 'admin';

  const filteredProducts = products.filter((p) => {
    if (!showArchived && !p.is_active) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q) ||
        (p.notes?.toLowerCase().includes(q) ?? false)
      );
    }
    return true;
  });

  const totalProducts = products.length;
  const activeProducts = products.filter((p) => p.is_active).length;
  const archivedProducts = products.filter((p) => !p.is_active).length;
  const totalAddons = products.filter((p) => p.is_addon && p.is_active).length;

  const handleActionClick = (actionName: string, callback: () => void) => {
    if (!isAdmin) {
      onForbiddenAttempt(actionName);
      return;
    }
    callback();
  };

  return (
    <div className="space-y-6">
      {/* RBAC State Banner if Non-Admin is viewing */}
      {!isAdmin && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 text-amber-900">
          <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-bold">FastAPI RBAC Simulation Notice:</span> You are currently viewing this screen as{' '}
            <strong className="underline uppercase">{userRole}</strong>. 
            Attempting any modification (POST / PUT / DELETE) will trigger FastAPI dependency injection rejection 
            (<code className="font-mono bg-amber-100 px-1 py-0.5 rounded">HTTP 403 Forbidden</code>). 
            Switch role to <strong>Admin</strong> in the top-right header to perform mutations.
          </div>
        </div>
      )}

      {/* Admin KPI Header Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="text-xs text-slate-500 font-medium">Total Catalog Records</div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums mt-1">
            {totalProducts}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">All database rows</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="text-xs text-emerald-600 font-medium flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Active Catalog Items
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums mt-1">
            {activeProducts}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Visible to subscribers</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="text-xs text-amber-600 font-medium flex items-center gap-1">
            <Archive className="w-3.5 h-3.5" />
            Archived (Soft Deleted)
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums mt-1">
            {archivedProducts}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Invoices preserved</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="text-xs text-indigo-600 font-medium flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            Switchable Add-ons
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 tabular-nums mt-1">
            {totalAddons}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Self-service toggles</div>
        </div>
      </div>

      {/* Control Strip */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products, SKUs, or notes..."
              className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <label className="flex items-center gap-2 text-xs text-slate-600 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showArchived}
              onChange={(e) => setShowArchived(e.target.checked)}
              className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
            />
            <span>Include Soft-Deleted Records</span>
          </label>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => handleActionClick('Create Product', () => onOpenProductModal())}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors whitespace-nowrap shadow-xs"
          >
            <Plus className="w-4 h-4" />
            Create Product
          </button>
        </div>
      </div>

      {/* Product List Table / Grid */}
      <div className="space-y-4">
        {filteredProducts.map((product) => {
          const isExpanded = expandedProductId === product.id;
          const grossMargin = product.sales_price - product.cost_price;
          const grossMarginPct =
            product.sales_price > 0 ? (grossMargin / product.sales_price) * 100 : 0;

          return (
            <div
              key={product.id}
              className={`bg-white rounded-xl border transition-all ${
                product.is_active
                  ? 'border-slate-200 shadow-xs'
                  : 'border-amber-200 bg-amber-50/20'
              }`}
            >
              {/* Product Primary Row */}
              <div className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-semibold capitalize text-slate-700">
                      {product.type}
                    </span>
                    <span aria-hidden="true" className="text-slate-300">·</span>
                    {product.is_addon ? (
                      <span className="text-indigo-600 font-medium">Add-on (Customer Switchable)</span>
                    ) : (
                      <span className="text-slate-500 font-medium">Core Platform Tier</span>
                    )}
                    <span aria-hidden="true" className="text-slate-300">·</span>
                    {product.is_active ? (
                      <span className="text-emerald-700 font-medium">Active</span>
                    ) : (
                      <span className="text-amber-800 font-medium bg-amber-100 px-2 py-0.5 rounded text-[11px]">
                        Archived / Soft-Deleted
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    {product.name}
                    {!product.is_active && (
                      <span className="text-xs font-normal text-amber-700">
                        (Excluded from Customer Catalog)
                      </span>
                    )}
                  </h3>

                  {product.notes && (
                    <p className="text-xs text-slate-500 max-w-2xl">{product.notes}</p>
                  )}
                </div>

                {/* Financial Margins Strip (Admin Exclusive) */}
                <div className="flex items-center gap-6 bg-slate-50 p-3 rounded-lg border border-slate-200 shrink-0">
                  <div>
                    <div className="text-[11px] text-slate-500">Sales Price</div>
                    <div className="text-sm font-bold font-mono text-slate-900 tabular-nums">
                      ${product.sales_price.toFixed(2)}
                    </div>
                  </div>

                  <div className="border-l border-slate-200 pl-4">
                    <div className="text-[11px] text-rose-600 font-medium flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Cost Price (COGS)
                    </div>
                    <div className="text-sm font-bold font-mono text-rose-700 tabular-nums">
                      ${product.cost_price.toFixed(2)}
                    </div>
                  </div>

                  <div className="border-l border-slate-200 pl-4">
                    <div className="text-[11px] text-emerald-700 font-medium">Gross Margin</div>
                    <div className="text-sm font-bold font-mono text-emerald-800 tabular-nums">
                      ${grossMargin.toFixed(2)} ({grossMarginPct.toFixed(1)}%)
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      handleActionClick('Edit Product', () => onOpenProductModal(product))
                    }
                    className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                    title="Edit product parameters"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  {product.is_active ? (
                    <button
                      type="button"
                      onClick={() =>
                        handleActionClick('Archive Product', () => setArchiveModalTarget(product))
                      }
                      className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg transition-colors"
                      title="Soft-delete: toggle is_active to False"
                    >
                      <Archive className="w-3.5 h-3.5" />
                      Archive
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() =>
                        handleActionClick('Restore Product', () => onRestoreProduct(product.id))
                      }
                      className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
                      title="Restore archived product to active catalog"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Restore
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() =>
                      setExpandedProductId(isExpanded ? null : product.id)
                    }
                    className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                  >
                    {isExpanded ? 'Collapse Sub-models' : 'Manage Variants & Plans'}
                  </button>
                </div>
              </div>

              {/* Sub-models Drawer: Variants and Plans */}
              {isExpanded && (
                <div className="border-t border-slate-200 bg-slate-50/60 p-5 space-y-6 rounded-b-xl">
                  {/* Relational Variants Section */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-indigo-600" />
                        <h4 className="text-sm font-bold text-slate-900">
                          Product Variants (Relational Brand Choices &amp; Price Modifiers)
                        </h4>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          handleActionClick('Add Variant', () => onOpenVariantModal(product))
                        }
                        className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Add Brand / Variant
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {product.variants.map((v) => {
                        const effectivePrice = product.sales_price + v.price_modifier;
                        return (
                          <div
                            key={v.id}
                            className="bg-white p-3.5 rounded-lg border border-slate-200 shadow-2xs space-y-2 flex flex-col justify-between"
                          >
                            <div>
                              <div className="flex items-center justify-between text-xs">
                                <span className="font-bold text-slate-900 truncate">
                                  {v.brand || v.variant_name}
                                </span>
                                {v.sku && (
                                  <span className="font-mono text-[10px] text-slate-400">
                                    {v.sku}
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-500 mt-0.5">
                                {v.variant_name}
                              </div>
                            </div>

                            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-mono tabular-nums">
                              <span className="text-slate-500">
                                Modifier: {v.price_modifier >= 0 ? `+` : ``}${v.price_modifier.toFixed(2)}
                              </span>
                              <span className="font-bold text-slate-900">
                                Eff: ${effectivePrice.toFixed(2)}
                              </span>
                            </div>

                            <div className="flex justify-end pt-1">
                              <button
                                type="button"
                                onClick={() =>
                                  handleActionClick('Edit Variant', () =>
                                    onOpenVariantModal(product, v)
                                  )
                                }
                                className="text-[11px] font-medium text-slate-500 hover:text-slate-800"
                              >
                                Edit Variant
                              </button>
                            </div>
                          </div>
                        );
                      })}
                      {product.variants.length === 0 && (
                        <div className="col-span-3 p-4 bg-white rounded-lg border border-dashed border-slate-200 text-xs text-slate-400 text-center">
                          No variants defined for this product yet. Click "+ Add Brand / Variant" to add one.
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Plans & Lifecycle Section */}
                  <div className="space-y-3 pt-4 border-t border-slate-200">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-indigo-600" />
                        <h4 className="text-sm font-bold text-slate-900">
                          Subscription Plans &amp; Lifecycle Flags (Daily, Weekly, Monthly, Yearly)
                        </h4>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          handleActionClick('Add Plan', () => onOpenPlanModal(product))
                        }
                        className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        Add Plan
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {product.plans.map((p) => (
                        <div
                          key={p.id}
                          className="bg-white p-4 rounded-lg border border-slate-200 shadow-2xs space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="font-bold text-sm text-slate-900">{p.name}</span>
                              <span className="capitalize ml-2 text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                                {p.billing_frequency}
                              </span>
                            </div>
                            <div className="text-sm font-bold font-mono text-slate-900 tabular-nums">
                              ${p.price.toFixed(2)}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded">
                            <div>Min Quantity: <strong className="text-slate-800">{p.minimum_quantity}</strong></div>
                            <div>
                              Availability: <span className="text-slate-500">{p.available_from || 'Open'} to {p.available_until || 'Ongoing'}</span>
                            </div>
                            <div>
                              Auto-Close: <strong className={p.allow_auto_close ? 'text-amber-600' : 'text-slate-400'}>{p.allow_auto_close ? 'Enabled' : 'No'}</strong>
                            </div>
                            <div>
                              Early Closure: <strong className={p.allow_early_closure ? 'text-emerald-600' : 'text-rose-600'}>{p.allow_early_closure ? 'Allowed' : 'Committed'}</strong>
                            </div>
                            <div>
                              Pause Renewal: <strong className={p.allow_pause ? 'text-emerald-600' : 'text-slate-400'}>{p.allow_pause ? 'Allowed' : 'No'}</strong>
                            </div>
                            <div>
                              Auto-Renew: <strong className={p.allow_renew ? 'text-emerald-600' : 'text-slate-400'}>{p.allow_renew ? 'Enabled' : 'No'}</strong>
                            </div>
                          </div>

                          <div className="flex justify-end">
                            <button
                              type="button"
                              onClick={() =>
                                handleActionClick('Edit Plan', () => onOpenPlanModal(product, p))
                              }
                              className="text-[11px] font-medium text-slate-500 hover:text-slate-800"
                            >
                              Edit Lifecycle Rules
                            </button>
                          </div>
                        </div>
                      ))}
                      {product.plans.length === 0 && (
                        <div className="col-span-2 p-4 bg-white rounded-lg border border-dashed border-slate-200 text-xs text-slate-400 text-center">
                          No plans configured for this product. Click "+ Add Plan" to configure cadences and lifecycle rules.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Archiving Service Soft-Delete Confirmation Modal */}
      {archiveModalTarget && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-slate-200">
            <div className="flex items-center gap-3 text-amber-700">
              <Archive className="w-6 h-6" />
              <h3 className="text-lg font-bold text-slate-900">
                Execute Soft-Delete Archiving Service
              </h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Are you sure you want to soft-delete <strong>{archiveModalTarget.name}</strong>?
            </p>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-2">
              <div className="font-semibold text-slate-800 flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-600" />
                Preservation of Historical Integrity:
              </div>
              <ul className="list-disc list-inside text-slate-600 space-y-1">
                <li>
                  Toggles <code className="font-mono bg-slate-200 px-1 py-0.5 rounded">is_active = False</code>.
                </li>
                <li>
                  Immediately filtered out of the Customer Catalog (subscribers can no longer select it).
                </li>
                <li>
                  Preserves existing customer subscriptions, ledger line items, and paid invoices without breaking Foreign Key relationships!
                </li>
              </ul>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setArchiveModalTarget(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onArchiveProduct(archiveModalTarget.id);
                  setArchiveModalTarget(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg shadow-xs"
              >
                Confirm Soft Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
