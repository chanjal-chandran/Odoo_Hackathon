import React, { useState } from 'react';
import { Product, ProductVariant } from '../types/catalog';
import { Tag } from 'lucide-react';

interface VariantModalProps {
  product: Product;
  variant?: ProductVariant;
  isOpen: boolean;
  onClose: () => void;
  onSave: (variantData: Partial<ProductVariant>) => void;
}

export const VariantModal: React.FC<VariantModalProps> = ({
  product,
  variant,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [variantName, setVariantName] = useState(variant?.variant_name || '');
  const [brand, setBrand] = useState(variant?.brand || '');
  const [priceModifier, setPriceModifier] = useState(
    variant?.price_modifier !== undefined ? variant.price_modifier.toString() : '560.00'
  );
  const [sku, setSku] = useState(variant?.sku || '');
  const [isActive, setIsActive] = useState(variant ? variant.is_active : true);

  const numModifier = parseFloat(priceModifier) || 0;
  const effectivePrice = product.sales_price + numModifier;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      product_id: product.id,
      variant_name: variantName.trim(),
      brand: brand.trim() || undefined,
      price_modifier: numModifier,
      sku: sku.trim() || undefined,
      is_active: isActive,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-lg w-full p-6 space-y-4 border border-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-900">
              {variant ? 'Edit Brand Variant' : 'Add Product Variant (Brand Choice)'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        <div className="text-xs text-slate-500">
          Configuring variant for parent product: <strong>{product.name}</strong> (Base: ${product.sales_price.toFixed(2)})
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Variant Title *
            </label>
            <input
              type="text"
              required
              value={variantName}
              onChange={(e) => setVariantName(e.target.value)}
              placeholder="e.g. Dedicated Sovereign Cloud Edition"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Brand Identifier (e.g. Brand Choice)
              </label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="e.g. Brightloop Elite Enterprise"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                SKU / Variant Code
              </label>
              <input
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="e.g. BL-CORE-ELITE-560"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Price Modifier Row */}
          <div className="p-3 bg-indigo-50/50 rounded-lg border border-indigo-100 space-y-2">
            <div>
              <label className="block font-semibold text-indigo-950 mb-1">
                Price Modifier ($) (e.g. adding 560 to base price) *
              </label>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold font-mono text-indigo-700">+</span>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={priceModifier}
                  onChange={(e) => setPriceModifier(e.target.value)}
                  placeholder="560.00"
                  className="w-full bg-white border border-indigo-200 rounded-lg p-2 text-slate-900 font-mono tabular-nums focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="pt-2 border-t border-indigo-100 flex items-center justify-between text-xs text-indigo-900 font-mono">
              <span>Final Effective Variant Price:</span>
              <span className="font-bold text-indigo-950 tabular-nums">
                ${effectivePrice.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="font-semibold text-slate-700">Variant Active</span>
            </label>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
              >
                {variant ? 'Save Variant' : 'Create Variant'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
