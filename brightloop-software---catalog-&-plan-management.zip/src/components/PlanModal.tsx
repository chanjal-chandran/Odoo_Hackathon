import React, { useState } from 'react';
import { Product, Plan, BillingFrequency } from '../types/catalog';
import { Calendar } from 'lucide-react';

interface PlanModalProps {
  product: Product;
  plan?: Plan;
  isOpen: boolean;
  onClose: () => void;
  onSave: (planData: Partial<Plan>) => void;
}

export const PlanModal: React.FC<PlanModalProps> = ({
  product,
  plan,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [name, setName] = useState(plan?.name || 'Enterprise Annual');
  const [frequency, setFrequency] = useState<BillingFrequency>(plan?.billing_frequency || 'monthly');
  const [price, setPrice] = useState(plan?.price?.toString() || product.sales_price.toString());
  const [minQty, setMinQty] = useState(plan?.minimum_quantity?.toString() || '1');
  const [availableFrom, setAvailableFrom] = useState(plan?.available_from || '2026-01-01');
  const [availableUntil, setAvailableUntil] = useState(plan?.available_until || '2027-12-31');
  
  // Lifecycle flags
  const [allowAutoClose, setAllowAutoClose] = useState(plan ? plan.allow_auto_close : false);
  const [allowEarlyClosure, setAllowEarlyClosure] = useState(plan ? plan.allow_early_closure : true);
  const [allowPause, setAllowPause] = useState(plan ? plan.allow_pause : true);
  const [allowRenew, setAllowRenew] = useState(plan ? plan.allow_renew : true);
  const [isActive, setIsActive] = useState(plan ? plan.is_active : true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      product_id: product.id,
      name: name.trim(),
      billing_frequency: frequency,
      price: parseFloat(price) || 0,
      minimum_quantity: parseInt(minQty, 10) || 1,
      available_from: availableFrom || undefined,
      available_until: availableUntil || undefined,
      allow_auto_close: allowAutoClose,
      allow_early_closure: allowEarlyClosure,
      allow_pause: allowPause,
      allow_renew: allowRenew,
      is_active: isActive,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-xl w-full p-6 space-y-4 border border-slate-200 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            <h3 className="text-base font-bold text-slate-900">
              {plan ? 'Edit Subscription Plan & Lifecycle' : 'Add Subscription Plan'}
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-sm font-bold"
          >
            ✕
          </button>
        </div>

        <div className="text-xs text-slate-500">
          Configuring plan linked to product: <strong>{product.name}</strong>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Plan Title *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Quarterly Growth Commitment"
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Billing Cadence *
              </label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as BillingFrequency)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500 capitalize"
              >
                <option value="daily">Daily Metered</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly Commitment</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Plan Price ($) *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 font-mono tabular-nums focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Min Quantity *
              </label>
              <input
                type="number"
                min="1"
                required
                value={minQty}
                onChange={(e) => setMinQty(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 font-mono tabular-nums focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Available From (Date)
              </label>
              <input
                type="date"
                value={availableFrom}
                onChange={(e) => setAvailableFrom(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Available Until (Date)
              </label>
              <input
                type="date"
                value={availableUntil}
                onChange={(e) => setAvailableUntil(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Lifecycle Rules Flags */}
          <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 space-y-2.5">
            <span className="font-bold text-slate-800 block text-xs">
              Subscription Lifecycle Rules (Boolean Flags)
            </span>

            <div className="grid grid-cols-2 gap-3">
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowRenew}
                  onChange={(e) => setAllowRenew(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 mt-0.5"
                />
                <div>
                  <span className="font-semibold text-slate-700 block">allow_renew</span>
                  <span className="text-[11px] text-slate-500">Auto-renews at end of billing period</span>
                </div>
              </label>

              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowPause}
                  onChange={(e) => setAllowPause(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 mt-0.5"
                />
                <div>
                  <span className="font-semibold text-slate-700 block">allow_pause</span>
                  <span className="text-[11px] text-slate-500">Subscribers can pause billing cycles</span>
                </div>
              </label>

              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowEarlyClosure}
                  onChange={(e) => setAllowEarlyClosure(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 mt-0.5"
                />
                <div>
                  <span className="font-semibold text-slate-700 block">allow_early_closure</span>
                  <span className="text-[11px] text-slate-500">Subscriber may terminate early</span>
                </div>
              </label>

              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowAutoClose}
                  onChange={(e) => setAllowAutoClose(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 mt-0.5"
                />
                <div>
                  <span className="font-semibold text-slate-700 block">allow_auto_close</span>
                  <span className="text-[11px] text-slate-500">Auto-terminates when sunset reaches</span>
                </div>
              </label>
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="font-semibold text-slate-700">Plan Active</span>
            </label>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs"
              >
                {plan ? 'Save Plan' : 'Create Plan'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
