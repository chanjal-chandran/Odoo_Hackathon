import React, { useState } from 'react';
import { CODE_FILES, CodeFile } from '../data/codeFiles';
import { Copy, Check, FileCode, Terminal, Download, ShieldCheck, Database, Sliders } from 'lucide-react';

export const CodeViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(CODE_FILES[0]);
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadAllFiles = () => {
    const combined = CODE_FILES.map(
      (f) => `### --- ${f.path} ---\n${f.content}\n\n`
    ).join('\n');
    const blob = new Blob([combined], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'brightloop_catalog_backend.py';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-indigo-700 font-semibold mb-1">
            <FileCode className="w-4 h-4" />
            <span>Python Backend Implementation</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-500 font-normal">FastAPI + SQLAlchemy + SQLite + Pydantic v2</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Catalog &amp; Plan Management Codebase
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Modular, production-grade Python files implementing the exact ORM models, Pydantic serialization
            filtering, variant pricing logic (+560 modifier), and FastAPI role-based access control.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={downloadAllFiles}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" />
            Download Source Bundle
          </button>
        </div>
      </div>

      {/* Architecture Highlights Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
          <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs">
            <Sliders className="w-4 h-4" />
            Additive Variant Pricing
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">ProductVariant.price_modifier</code>{' '}
            dynamically adjusts the base product sales price (e.g. adding +560.00 for elite enterprise brand choice).
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
          <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs">
            <ShieldCheck className="w-4 h-4" />
            Strict Data Redaction
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Pydantic’s <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">CustomerProductResponse</code>{' '}
            guarantees <code className="font-mono">cost_price</code> is never leaked in customer JSON payloads.
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-1.5">
          <div className="flex items-center gap-2 text-amber-600 font-bold text-xs">
            <Database className="w-4 h-4" />
            Invoice-Safe Soft Delete
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Toggling <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">is_active=False</code> excludes items
            from the catalog while keeping past subscriptions, invoices, and accounting records intact.
          </p>
        </div>
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: File Navigator */}
        <div className="lg:col-span-4 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block px-1">
            Backend Source Files
          </span>

          <div className="space-y-1.5">
            {CODE_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-3 rounded-lg border text-xs transition-all ${
                    isSelected
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-semibold ring-1 ring-indigo-600'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono font-bold">{file.name}</span>
                    <span className="text-[10px] text-slate-400 font-mono">Python</span>
                  </div>
                  <div className="text-[11px] text-slate-500 line-clamp-2">
                    {file.description}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="p-4 bg-slate-900 text-slate-300 rounded-xl text-xs space-y-2 mt-4 font-mono">
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <Terminal className="w-4 h-4" />
              <span>Run Local Server</span>
            </div>
            <div className="text-[11px] text-slate-400">
              # Install dependencies<br />
              pip install -r requirements.txt<br /><br />
              # Start FastAPI with Uvicorn<br />
              uvicorn backend.main:app --reload<br /><br />
              # Run test suite<br />
              pytest backend/test_api.py -v
            </div>
          </div>
        </div>

        {/* Right: Code Viewer */}
        <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-800 flex flex-col overflow-hidden shadow-sm">
          {/* Code Window Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-mono text-slate-200 font-semibold">{selectedFile.path}</span>
            </div>

            <button
              type="button"
              onClick={copyToClipboard}
              className="flex items-center gap-1 px-2.5 py-1 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors text-[11px]"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy File'}</span>
            </button>
          </div>

          {/* Code Content */}
          <pre className="p-5 text-slate-200 text-xs font-mono overflow-auto leading-relaxed max-h-[640px]">
            {selectedFile.content}
          </pre>
        </div>
      </div>
    </div>
  );
};
