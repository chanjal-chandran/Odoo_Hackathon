export type BillingFrequency = 'daily' | 'weekly' | 'monthly' | 'yearly';

export type UserRole = 'customer' | 'admin' | 'unauthenticated';

export interface ProductVariant {
  id: number;
  product_id: number;
  variant_name: string;
  brand?: string;
  price_modifier: number;
  sku?: string;
  is_active: boolean;
}

export interface Plan {
  id: number;
  product_id: number;
  name: string;
  billing_frequency: BillingFrequency;
  price: number;
  minimum_quantity: number;
  available_from?: string;
  available_until?: string;
  allow_auto_close: boolean;
  allow_early_closure: boolean;
  allow_pause: boolean;
  allow_renew: boolean;
  is_active: boolean;
}

export interface Product {
  id: number;
  name: string;
  type: string;
  sales_price: number;
  cost_price: number; // Internal COGS (hidden from customers)
  notes?: string;
  is_addon: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  variants: ProductVariant[];
  plans: Plan[];
}

export interface CustomerProductView {
  id: number;
  name: string;
  type: string;
  sales_price: number;
  // NOTE: cost_price is strictly omitted!
  notes?: string;
  is_addon: boolean;
  variants: ProductVariant[];
  plans: Plan[];
}
