/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Product, ProductVariant, Plan, UserRole } from './types/catalog';
import { INITIAL_PRODUCTS } from './data/seedData';
import { Navbar } from './components/Navbar';
import { CustomerCatalogView } from './components/CustomerCatalogView';
import { AdminConsoleView } from './components/AdminConsoleView';
import { ApiExplorerView } from './components/ApiExplorerView';
import { CodeViewer } from './components/CodeViewer';
import { ProductModal } from './components/ProductModal';
import { VariantModal } from './components/VariantModal';
import { PlanModal } from './components/PlanModal';
import { ShieldAlert, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [userRole, setUserRole] = useState<UserRole>('customer');
  const [activeTab, setActiveTab] = useState<'catalog' | 'admin' | 'api' | 'code'>('catalog');
  const [apiEndpointToInspect, setApiEndpointToInspect] = useState<string>('GET /catalog');

  // Modals state
  const [productModal, setProductModal] = useState<{ isOpen: boolean; product?: Product }>({
    isOpen: false,
  });
  const [variantModal, setVariantModal] = useState<{
    isOpen: boolean;
    product?: Product;
    variant?: ProductVariant;
  }>({
    isOpen: false,
  });
  const [planModal, setPlanModal] = useState<{
    isOpen: boolean;
    product?: Product;
    plan?: Plan;
  }>({
    isOpen: false,
  });

  // Forbidden modal simulation state
  const [forbiddenAction, setForbiddenAction] = useState<string | null>(null);

  // Success toast message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Product CRUD
  const handleSaveProduct = (productData: Partial<Product>) => {
    if (productModal.product) {
      // Update existing
      setProducts((prev) =>
        prev.map((p) =>
          p.id === productModal.product!.id
            ? {
                ...p,
                ...productData,
                updated_at: new Date().toISOString(),
              }
            : p
        )
      );
      showToast(`Product "${productData.name}" updated successfully.`);
    } else {
      // Create new
      const newId = Math.max(...products.map((p) => p.id), 0) + 1;
      const newProduct: Product = {
        id: newId,
        name: productData.name || 'Untitled Product',
        type: productData.type || 'subscription',
        sales_price: productData.sales_price || 0,
        cost_price: productData.cost_price || 0,
        notes: productData.notes,
        is_addon: productData.is_addon || false,
        is_active: productData.is_active ?? true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        variants: [],
        plans: [],
      };
      setProducts((prev) => [...prev, newProduct]);
      showToast(`Product "${newProduct.name}" created.`);
    }
  };

  // Archiving Service: Soft Delete
  const handleArchiveProduct = (productId: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, is_active: false } : p))
    );
    showToast('Product soft-deleted (archived). Historical subscription invoices preserved.');
  };

  // Restore Product
  const handleRestoreProduct = (productId: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, is_active: true } : p))
    );
    showToast('Product restored to active catalog.');
  };

  // Variant CRUD
  const handleSaveVariant = (variantData: Partial<ProductVariant>) => {
    const parentProduct = variantModal.product;
    if (!parentProduct) return;

    if (variantModal.variant) {
      // Update variant
      setProducts((prev) =>
        prev.map((p) => {
          if (p.id !== parentProduct.id) return p;
          return {
            ...p,
            variants: p.variants.map((v) =>
              v.id === variantModal.variant!.id ? { ...v, ...variantData } : v
            ),
          };
        })
      );
      showToast(`Variant "${variantData.variant_name}" updated.`);
    } else {
      // Add variant
      const allVariantIds = products.flatMap((p) => p.variants.map((v) => v.id));
      const newVariantId = (allVariantIds.length ? Math.max(...allVariantIds) : 100) + 1;
      const newVariant: ProductVariant = {
        id: newVariantId,
        product_id: parentProduct.id,
        variant_name: variantData.variant_name || 'New Variant',
        brand: variantData.brand,
        price_modifier: variantData.price_modifier || 0,
        sku: variantData.sku,
        is_active: variantData.is_active ?? true,
      };

      setProducts((prev) =>
        prev.map((p) =>
          p.id === parentProduct.id
            ? { ...p, variants: [...p.variants, newVariant] }
            : p
        )
      );
      showToast(`Variant added with price modifier: +$${newVariant.price_modifier.toFixed(2)}.`);
    }
  };

  // Plan CRUD
  const handleSavePlan = (planData: Partial<Plan>) => {
    const parentProduct = planModal.product;
    if (!parentProduct) return;

    if (planModal.plan) {
      // Update plan
      setProducts((prev) =>
        prev.map((p) => {
          if (p.id !== parentProduct.id) return p;
          return {
            ...p,
            plans: p.plans.map((pl) =>
              pl.id === planModal.plan!.id ? { ...pl, ...planData } : pl
            ),
          };
        })
      );
      showToast(`Subscription plan "${planData.name}" updated.`);
    } else {
      // Add plan
      const allPlanIds = products.flatMap((p) => p.plans.map((pl) => pl.id));
      const newPlanId = (allPlanIds.length ? Math.max(...allPlanIds) : 200) + 1;
      const newPlan: Plan = {
        id: newPlanId,
        product_id: parentProduct.id,
        name: planData.name || 'New Plan',
        billing_frequency: planData.billing_frequency || 'monthly',
        price: planData.price || 0,
        minimum_quantity: planData.minimum_quantity || 1,
        available_from: planData.available_from,
        available_until: planData.available_until,
        allow_auto_close: planData.allow_auto_close ?? false,
        allow_early_closure: planData.allow_early_closure ?? true,
        allow_pause: planData.allow_pause ?? true,
        allow_renew: planData.allow_renew ?? true,
        is_active: planData.is_active ?? true,
      };

      setProducts((prev) =>
        prev.map((p) =>
          p.id === parentProduct.id ? { ...p, plans: [...p.plans, newPlan] } : p
        )
      );
      showToast(`Plan "${newPlan.name}" configured with lifecycle rules.`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900">
      {/* 3-Zone Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        userRole={userRole}
        setUserRole={setUserRole}
      />

      {/* Main Workspace Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'catalog' && (
          <CustomerCatalogView
            products={products}
            onOpenApiInspector={(endpoint) => {
              setApiEndpointToInspect(endpoint);
              setActiveTab('api');
            }}
          />
        )}

        {activeTab === 'admin' && (
          <AdminConsoleView
            products={products}
            userRole={userRole}
            onOpenProductModal={(p) => setProductModal({ isOpen: true, product: p })}
            onOpenVariantModal={(p, v) => setVariantModal({ isOpen: true, product: p, variant: v })}
            onOpenPlanModal={(p, pl) => setPlanModal({ isOpen: true, product: p, plan: pl })}
            onArchiveProduct={handleArchiveProduct}
            onRestoreProduct={handleRestoreProduct}
            onForbiddenAttempt={(action) => setForbiddenAction(action)}
          />
        )}

        {activeTab === 'api' && (
          <ApiExplorerView
            products={products}
            userRole={userRole}
            initialEndpoint={apiEndpointToInspect}
          />
        )}

        {activeTab === 'code' && <CodeViewer />}
      </main>

      {/* Product Modal */}
      <ProductModal
        isOpen={productModal.isOpen}
        product={productModal.product}
        onClose={() => setProductModal({ isOpen: false })}
        onSave={handleSaveProduct}
      />

      {/* Variant Modal */}
      {variantModal.product && (
        <VariantModal
          isOpen={variantModal.isOpen}
          product={variantModal.product}
          variant={variantModal.variant}
          onClose={() => setVariantModal({ isOpen: false })}
          onSave={handleSaveVariant}
        />
      )}

      {/* Plan Modal */}
      {planModal.product && (
        <PlanModal
          isOpen={planModal.isOpen}
          product={planModal.product}
          plan={planModal.plan}
          onClose={() => setPlanModal({ isOpen: false })}
          onSave={handleSavePlan}
        />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 text-xs font-medium border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Forbidden 403 Simulation Modal */}
      {forbiddenAction && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4 border border-rose-200">
            <div className="flex items-center gap-3 text-rose-600">
              <ShieldAlert className="w-6 h-6" />
              <h3 className="text-base font-bold text-slate-900">
                HTTP 403 Forbidden: Insufficient Permissions
              </h3>
            </div>

            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs font-mono text-rose-900 leading-relaxed">
              FastAPI HTTPException(status_code=403)<br />
              Detail: "Access forbidden: Insufficient permissions. Endpoint requires 'admin' privileges, but user role is '{userRole}'."
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Customers are strictly granted read-only access for the catalog so they can manage their own subscriptions without having to email anyone. Administrative actions ({forbiddenAction}) are guarded by <code className="font-mono bg-slate-100 px-1 py-0.5 rounded">Depends(require_admin)</code>.
            </p>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => {
                  setUserRole('admin');
                  setForbiddenAction(null);
                  showToast('Role switched to Admin.');
                }}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                Switch to Admin Role &rarr;
              </button>

              <button
                type="button"
                onClick={() => setForbiddenAction(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clean Editorial Footer */}
      <footer className="border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            Brightloop Software &copy; 2026. Catalog and Plan Management Module.
          </div>
          <div className="flex items-center gap-4">
            <span>FastAPI 0.110</span>
            <span aria-hidden="true">·</span>
            <span>SQLAlchemy 2.0 (SQLite)</span>
            <span aria-hidden="true">·</span>
            <span>Pydantic v2</span>
            <span aria-hidden="true">·</span>
            <span>RBAC Dependency Injection</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
