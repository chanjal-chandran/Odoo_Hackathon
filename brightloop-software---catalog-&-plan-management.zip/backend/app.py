"""
Brightloop Software - Catalog and Plan Management Module
Flask Application Entrypoint.

Unified Subscription Business Platform:
- Flask framework with Blueprints architecture
- SQLite database persistence with SQLAlchemy ORM
- Customer Catalog (Read-Only) filtering cost_price and archived items via Pydantic
- Admin Management (Full CRUD, Soft-Delete Archiving, Variant Modifiers, Lifecycle Rules)
- Role-Based Access Control enforcing Admin vs Customer security boundaries
"""

from flask import Flask, jsonify
from .blueprints.admin import admin_bp
from .blueprints.catalog import catalog_bp
from .database import db_session, init_db
from .seed import seed_database


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["JSON_SORT_KEYS"] = False

    # Initialize SQLite database schema and seed demonstration catalog records
    init_db()
    seed_database()

    # Tear down scoped database session after each request
    @app.teardown_appcontext
    def shutdown_session(exception=None):
        db_session.remove()

    # Register Blueprints
    app.register_blueprint(catalog_bp)
    app.register_blueprint(admin_bp)

    @app.route("/health", methods=["GET"])
    def health_check():
        return jsonify({
            "status": "operational",
            "service": "Brightloop Catalog & Plan Management",
            "framework": "Flask 3.x",
            "database": "SQLite (brightloop.db)"
        }), 200

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
