"""
Automated Test Suite for Brightloop Software Catalog and Plan Management API (Flask).
Uses Flask TestClient with SQLite database.

Tests:
1. Role-based access control (RBAC): Customer restricted to read-only; 403 on admin mutations.
2. Security & privacy: Customer catalog payload strictly omits `cost_price`.
3. Archiving Service: Soft-deleting toggles `is_active=False` and immediately hides product from catalog.
4. Variant pricing: Brand modifier calculation (+560 to base price).
5. Plan lifecycle rules validation.
"""

import pytest
from .app import app

ADMIN_HEADERS = {"Authorization": "Bearer admin-token-brightloop"}
CUSTOMER_HEADERS = {"Authorization": "Bearer customer-token-subscriber"}
UNAUTH_HEADERS = {}


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_customer_catalog_security(client):
    """Verify that customer catalog excludes cost_price and excludes archived products."""
    response = client.get("/catalog", headers=CUSTOMER_HEADERS)
    assert response.status_code == 200
    products = response.get_json()
    assert len(products) > 0

    for prod in products:
        # Crucial Security Invariant: cost_price must never leak to customers
        assert "cost_price" not in prod, "CRITICAL: cost_price leaked in customer catalog!"
        assert "gross_margin" not in prod
        assert "gross_margin_percent" not in prod
        
        # Verify that archived/inactive products are not returned
        assert "Legacy Billing Connector v1 (Sunset)" not in prod["name"]


def test_rbac_customer_forbidden_from_admin_crud(client):
    """Verify customer role cannot create or modify products (HTTP 403 Forbidden)."""
    payload = {
        "name": "Unauthorized Attempt",
        "type": "subscription",
        "sales_price": 500.0,
        "cost_price": 200.0,
        "is_addon": False,
        "is_active": True
    }
    response = client.post("/admin/products", json=payload, headers=CUSTOMER_HEADERS)
    assert response.status_code == 403
    data = response.get_json()
    assert "Insufficient permissions" in data["detail"]


def test_rbac_unauthenticated_rejected(client):
    """Verify unauthenticated requests are rejected with 401 Unauthorized."""
    response = client.get("/catalog", headers=UNAUTH_HEADERS)
    assert response.status_code == 401


def test_admin_crud_and_margin_calculation(client):
    """Verify admin can create a product and receives cost_price and calculated margin."""
    payload = {
        "name": "Automated Multi-Cloud Broker",
        "type": "service",
        "sales_price": 1000.0,
        "cost_price": 250.0,
        "notes": "Test ledger recon engine",
        "is_addon": True,
        "is_active": True
    }
    response = client.post("/admin/products", json=payload, headers=ADMIN_HEADERS)
    assert response.status_code == 201
    data = response.get_json()
    assert data["cost_price"] == 250.0
    assert data["gross_margin"] == 750.0  # 1000 - 250
    assert data["gross_margin_percent"] == 75.0


def test_variant_with_price_modifier(client):
    """Verify creating a variant with +560 brand price modifier."""
    prod_resp = client.post("/admin/products", json={
        "name": "Cloud Infrastructure Tier",
        "type": "subscription",
        "sales_price": 1000.0,
        "cost_price": 400.0,
        "is_addon": False,
        "is_active": True
    }, headers=ADMIN_HEADERS)
    product_id = prod_resp.get_json()["id"]

    # Create variant with +560 modifier for brand choice
    variant_resp = client.post("/admin/variants", json={
        "product_id": product_id,
        "variant_name": "Enterprise Dedicated Brand",
        "brand": "Brightloop Elite",
        "price_modifier": 560.0,
        "sku": f"TEST-BL-ELITE-{product_id}",
        "is_active": True
    }, headers=ADMIN_HEADERS)
    assert variant_resp.status_code == 201
    vdata = variant_resp.get_json()
    assert vdata["price_modifier"] == 560.0
    assert vdata["brand"] == "Brightloop Elite"


def test_archiving_soft_delete_service(client):
    """Verify archiving toggles is_active=False and removes item from customer view."""
    prod_resp = client.post("/admin/products", json={
        "name": "Temporary Special Offer",
        "type": "subscription",
        "sales_price": 199.0,
        "cost_price": 50.0,
        "is_addon": False,
        "is_active": True
    }, headers=ADMIN_HEADERS)
    product_id = prod_resp.get_json()["id"]

    # Verify present in catalog
    catalog_before = client.get("/catalog", headers=CUSTOMER_HEADERS).get_json()
    assert any(p["id"] == product_id for p in catalog_before)

    # Admin soft-deletes (archives) the product
    archive_resp = client.delete(f"/admin/products/{product_id}/archive", headers=ADMIN_HEADERS)
    assert archive_resp.status_code == 200
    assert archive_resp.get_json()["is_active"] is False

    # Verify immediately excluded from customer catalog
    catalog_after = client.get("/catalog", headers=CUSTOMER_HEADERS).get_json()
    assert not any(p["id"] == product_id for p in catalog_after)

    # Verify still exists in admin database for historical integrity
    admin_prod = client.get(f"/admin/products/{product_id}", headers=ADMIN_HEADERS).get_json()
    assert admin_prod["id"] == product_id
    assert admin_prod["is_active"] is False
