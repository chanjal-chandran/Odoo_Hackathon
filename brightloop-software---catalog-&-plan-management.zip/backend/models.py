"""
SQLAlchemy ORM Models for Brightloop Software Catalog and Plan Management.

Entities:
- Product: Base subscription entity with sales and cost prices, add-on flag, and soft-delete status.
- ProductVariant: Brand and specification variants with price modifiers (e.g., +560 for premium brand choice).
- Plan: Billing cadence, quantity constraints, availability window, and lifecycle rules.
"""

from datetime import datetime, timezone
import enum
from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    Enum as SqlEnum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from .database import Base


class BillingFrequency(str, enum.Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"


class Product(Base):
    """
    Core product entity representing either a standalone subscription,
    core service, or modular add-on.
    
    Includes soft-deleting via `is_active` to preserve data integrity
    for historical invoices and active subscriber state.
    """
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    type = Column(String(100), nullable=False, default="subscription")  # subscription, service, license, hardware
    sales_price = Column(Float, nullable=False)                         # Base customer-facing price
    cost_price = Column(Float, nullable=False)                          # Internal COGS / vendor unit cost (Restricted to Admins)
    notes = Column(Text, nullable=True)                                 # Internal or descriptive product notes
    
    # Add-on flag: customers can switch this add-on on and off in their subscription life
    is_addon = Column(Boolean, default=False, nullable=False)
    
    # Soft-delete flag: preserves relational integrity for past invoices & subscriptions
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = Column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        nullable=False
    )

    # Relationships
    variants = relationship(
        "ProductVariant",
        back_populates="product",
        cascade="all, delete-orphan",
        order_by="ProductVariant.id"
    )
    plans = relationship(
        "Plan",
        back_populates="product",
        cascade="all, delete-orphan",
        order_by="Plan.id"
    )

    def __repr__(self):
        return f"<Product id={self.id} name='{self.name}' sales_price={self.sales_price} active={self.is_active}>"


class ProductVariant(Base):
    """
    Product variant entity (e.g., brand choice, hardware spec, tier level).
    
    Variant Pricing Logic:
    Each variant defines a `price_modifier` that is applied directly to the product's
    base `sales_price`. For example, selecting the 'Brightloop Elite Enterprise' brand
    variant specifies a price_modifier of +560.00, yielding:
        effective_price = product.sales_price + variant.price_modifier
    """
    __tablename__ = "product_variants"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    variant_name = Column(String(255), nullable=False)  # e.g., "White-Label Brand Edition", "Enterprise Spec"
    brand = Column(String(150), nullable=True)          # e.g., "Brightloop Elite", "Partner Brand X"
    
    # Price modifier: added to product.sales_price (e.g., 560.00 for a specific premium brand choice)
    price_modifier = Column(Float, default=0.0, nullable=False)
    
    sku = Column(String(100), nullable=True, unique=True)
    is_active = Column(Boolean, default=True, nullable=False)

    # Relationship
    product = relationship("Product", back_populates="variants")

    @property
    def effective_price(self) -> float:
        """Computes the final variant price applying the modifier to product base price."""
        if self.product:
            return round(self.product.sales_price + self.price_modifier, 2)
        return self.price_modifier

    def __repr__(self):
        return f"<ProductVariant id={self.id} brand='{self.brand}' modifier=+{self.price_modifier}>"


class Plan(Base):
    """
    Subscription plan linked to a product. Dictates billing cadence,
    pricing, quantity commitments, availability window, and lifecycle rules.
    
    Lifecycle Rules:
    - allow_auto_close: Automatically terminate subscription at contract term expiration.
    - allow_early_closure: Permit customer to cancel subscription before scheduled term.
    - allow_pause: Enable customer to temporarily pause subscription billing cycles.
    - allow_renew: Permit automatic renewal and extension upon cycle completion.
    """
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)          # e.g., "Quarterly Pro", "Annual Commitment"
    
    # Frequency: daily, weekly, monthly, or yearly
    billing_frequency = Column(SqlEnum(BillingFrequency), nullable=False, default=BillingFrequency.MONTHLY)
    
    # Recurring plan price (allows override or package pricing)
    price = Column(Float, nullable=False)
    
    # Minimum required quantity (e.g., minimum 5 seats/units)
    minimum_quantity = Column(Integer, default=1, nullable=False)
    
    # Specific date range the plan remains available for new subscribers
    available_from = Column(Date, nullable=True)
    available_until = Column(Date, nullable=True)
    
    # Lifecycle rule boolean flags
    allow_auto_close = Column(Boolean, default=False, nullable=False)   # Term auto-closure flag
    allow_early_closure = Column(Boolean, default=True, nullable=False)  # Early customer cancellation permitted
    allow_pause = Column(Boolean, default=True, nullable=False)          # Customer-initiated billing pause
    allow_renew = Column(Boolean, default=True, nullable=False)          # Auto-renewal enabled

    is_active = Column(Boolean, default=True, nullable=False)

    # Relationship
    product = relationship("Product", back_populates="plans")

    def __repr__(self):
        return f"<Plan id={self.id} name='{self.name}' freq={self.billing_frequency} price={self.price}>"
