"""
Role-Based Access Control (RBAC) & Authentication for Flask in Brightloop Software.

Security Architecture:
- Admin Role: Full operational privileges over products, pricing modifiers, lifecycle rules,
  and soft-delete archiving.
- Customer Role: Strictly granted read-only catalog access. This empowers subscribers to
  browse active catalog offerings, evaluate add-ons, and self-manage plan selection
  without submitting support tickets or emailing administrators.
"""

from enum import Enum
from functools import wraps
from typing import List, Optional
from flask import g, jsonify, request
from pydantic import BaseModel


class UserRole(str, Enum):
    ADMIN = "admin"
    CUSTOMER = "customer"


class AuthenticatedUser(BaseModel):
    user_id: str
    email: str
    role: UserRole


# Pre-configured mock credentials for development and demonstration
MOCK_USERS = {
    "admin-token-brightloop": AuthenticatedUser(
        user_id="usr_admin_001",
        email="operations@brightloop.io",
        role=UserRole.ADMIN
    ),
    "customer-token-subscriber": AuthenticatedUser(
        user_id="usr_cust_882",
        email="subscriber@enterprise-client.com",
        role=UserRole.CUSTOMER
    )
}


def get_current_user_from_request() -> Optional[AuthenticatedUser]:
    """Extracts bearer token and returns validated user object or None."""
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        return None

    token = auth_header.split(" ", 1)[1].strip()

    if token in MOCK_USERS:
        return MOCK_USERS[token]
    if token.lower() in ("admin", "role_admin"):
        return MOCK_USERS["admin-token-brightloop"]
    if token.lower() in ("customer", "role_customer"):
        return MOCK_USERS["customer-token-subscriber"]

    return None


def require_role(allowed_roles: List[UserRole]):
    """
    Decorator implementing role-based access control for Flask endpoints.
    
    Enforcement:
    1. Returns HTTP 401 if missing or invalid token.
    2. Returns HTTP 403 if user role is not within `allowed_roles`.
    3. Attaches `g.current_user` for route handler access.
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user = get_current_user_from_request()
            if not user:
                return jsonify({
                    "detail": "Authentication required. Provide a valid Bearer token in the Authorization header."
                }), 401

            if user.role not in allowed_roles:
                return jsonify({
                    "detail": (
                        f"Access forbidden: Insufficient permissions. Endpoint requires "
                        f"'{[r.value for r in allowed_roles]}' privileges, but user role is '{user.role.value}'. "
                        f"Customers are strictly granted read-only access for the catalog."
                    )
                }), 403

            g.current_user = user
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# Convenience decorators
require_admin = require_role([UserRole.ADMIN])
require_customer_or_admin = require_role([UserRole.ADMIN, UserRole.CUSTOMER])
