"""
Database Configuration for Brightloop Software Catalog & Plan Management.
Uses SQLite via SQLAlchemy with thread-safe session management for Flask.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, scoped_session, sessionmaker

SQLALCHEMY_DATABASE_URL = "sqlite:///./brightloop.db"

# connect_args={"check_same_thread": False} allows multi-threaded Flask request handling
engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False
)

# scoped_session guarantees thread-local database sessions across Flask request contexts
db_session = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))

Base = declarative_base()
Base.query = db_session.query_property()


def init_db():
    """Initializes SQLite schema tables."""
    Base.metadata.create_all(bind=engine)
