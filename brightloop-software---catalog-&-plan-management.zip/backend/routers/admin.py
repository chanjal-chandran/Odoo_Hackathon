"""
Admin Management Router for Brightloop Software.

Features:
1. Full CRUD for Products, Brand Variants, and Plans.
2. Financial transparency: Exposes cost_price and calculates margin performance.
3. Archiving Service (Soft Delete): Toggles `is_active = False` on products to
   preserve referential integrity for historical subscriptions, reporting,
   and past invoices without orphan errors.
4. Strict access control: Every endpoint is guarded by `require_admin`.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session, joinedload

from ..auth import AuthenticatedUser, require_admin
from ..database import get_db
from ..models import BillingFrequency, Plan, Product, ProductVariant
from ..schemas import (
    AdminProductResponse,
    ArchiveResponse,
    PlanCreate,
    PlanResponse,
    PlanUpdate,
    ProductCreate,
    ProductUpdate,
    VariantCreate,
    VariantResponse,
    VariantUpdate,
)

router = APIRouter(
    prefix="/admin",
    tags=["Admin Product & Plan Management"],
    dependencies=[Depends(require_admin)]
)


# -----------------------------------------------------------------------------
# Product Operations (CRUD + Soft Delete)
# -----------------------------------------------------------------------------

@router.get(
    "/products",
    response_model=List[AdminProductResponse],
    summary="List all products (Admin View)",
    description="Returns all products including cost prices, gross margins, and archived/soft-deleted items."
)
def list_admin_products(
    include_archived: bool = Query(True, description="Whether to include soft-deleted products"),
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> List[Product]:
    query = db.query(Product).options(
        joinedload(Product.variants),
        joinedload(Product.plans)
    )
    if not include_archived:
        query = query.filter(Product.is_active.is_(True))
    return query.order_by(Product.id.asc()).all()


@router.post(
    "/products",
    response_model=AdminProductResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new subscription product or add-on"
)
def create_product(
    payload: ProductCreate,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> Product:
    new_product = Product(
        name=payload.name,
        type=payload.type,
        sales_price=payload.sales_price,
        cost_price=payload.cost_price,
        notes=payload.notes,
        is_addon=payload.is_addon,
        is_active=payload.is_active
    )
    db.add(new_product)
    db.commit()
    db.refresh(new_product)
    return new_product


@router.get(
    "/products/{product_id}",
    response_model=AdminProductResponse,
    summary="Get single product admin details"
)
def get_product_details(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> Product:
    product = (
        db.query(Product)
        .options(joinedload(Product.variants), joinedload(Product.plans))
        .filter(Product.id == product_id)
        .first()
    )
    if not product:
        raise HTTPException(status_code=404, detail=f"Product with id {product_id} not found.")
    return product


@router.put(
    "/products/{product_id}",
    response_model=AdminProductResponse,
    summary="Update product details"
)
def update_product(
    product_id: int,
    payload: ProductUpdate,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> Product:
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail=f"Product with id {product_id} not found.")

    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(product, field, value)

    db.commit()
    db.refresh(product)
    return product


@router.delete(
    "/products/{product_id}/archive",
    response_model=ArchiveResponse,
    summary="Soft-delete (archive) a product",
    description=(
        "Toggles `is_active` to False. Soft deleting preserves relational integrity "
        "so that past subscription billing cycles, historical invoices, and audit logs "
        "remain completely intact."
    )
)
def archive_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> ArchiveResponse:
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail=f"Product with id {product_id} not found.")

    product.is_active = False
    db.commit()

    return ArchiveResponse(
        product_id=product.id,
        name=product.name,
        is_active=False,
        message=(
            f"Product '{product.name}' successfully archived. "
            f"Historical subscriptions, invoices, and billing records remain fully intact."
        )
    )


@router.post(
    "/products/{product_id}/restore",
    response_model=ArchiveResponse,
    summary="Restore an archived product"
)
def restore_product(
    product_id: int,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> ArchiveResponse:
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail=f"Product with id {product_id} not found.")

    product.is_active = True
    db.commit()

    return ArchiveResponse(
        product_id=product.id,
        name=product.name,
        is_active=True,
        message=f"Product '{product.name}' is now active and visible in the customer catalog."
    )


# -----------------------------------------------------------------------------
# Product Variant Management (Relational Brand Choices & Modifiers)
# -----------------------------------------------------------------------------

@router.post(
    "/variants",
    response_model=VariantResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create product variant with price modifier",
    description=(
        "Configures a variant (such as brand option) with a price_modifier column "
        "(e.g., adding +560.00 to the base price for a specific brand choice)."
    )
)
def create_variant(
    payload: VariantCreate,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> ProductVariant:
    product = db.query(Product).filter(Product.id == payload.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail=f"Target product {payload.product_id} does not exist.")

    variant = ProductVariant(
        product_id=payload.product_id,
        variant_name=payload.variant_name,
        brand=payload.brand,
        price_modifier=payload.price_modifier,
        sku=payload.sku,
        is_active=payload.is_active
    )
    db.add(variant)
    db.commit()
    db.refresh(variant)
    return variant


@router.put(
    "/variants/{variant_id}",
    response_model=VariantResponse,
    summary="Update product variant"
)
def update_variant(
    variant_id: int,
    payload: VariantUpdate,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> ProductVariant:
    variant = db.query(ProductVariant).filter(ProductVariant.id == variant_id).first()
    if not variant:
        raise HTTPException(status_code=404, detail=f"Variant with id {variant_id} not found.")

    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(variant, field, value)

    db.commit()
    db.refresh(variant)
    return variant


# -----------------------------------------------------------------------------
# Plan Management (Billing Cadence & Lifecycle Rules)
# -----------------------------------------------------------------------------

@router.post(
    "/plans",
    response_model=PlanResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create subscription plan linked to product",
    description=(
        "Defines billing frequency (daily, weekly, monthly, yearly), minimum quantity, "
        "availability dates, and lifecycle rules (auto-close, early closure, pause, renew)."
    )
)
def create_plan(
    payload: PlanCreate,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> Plan:
    product = db.query(Product).filter(Product.id == payload.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail=f"Parent product {payload.product_id} does not exist.")

    if payload.available_from and payload.available_until:
        if payload.available_from > payload.available_until:
            raise HTTPException(
                status_code=400,
                detail="available_from date must precede available_until date."
            )

    plan = Plan(
        product_id=payload.product_id,
        name=payload.name,
        billing_frequency=payload.billing_frequency,
        price=payload.price,
        minimum_quantity=payload.minimum_quantity,
        available_from=payload.available_from,
        available_until=payload.available_until,
        allow_auto_close=payload.allow_auto_close,
        allow_early_closure=payload.allow_early_closure,
        allow_pause=payload.allow_pause,
        allow_renew=payload.allow_renew,
        is_active=payload.is_active
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


@router.put(
    "/plans/{plan_id}",
    response_model=PlanResponse,
    summary="Update plan details and lifecycle flags"
)
def update_plan(
    plan_id: int,
    payload: PlanUpdate,
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_admin)
) -> Plan:
    plan = db.query(Plan).filter(Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail=f"Plan with id {plan_id} not found.")

    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(plan, field, value)

    db.commit()
    db.refresh(plan)
    return plan
