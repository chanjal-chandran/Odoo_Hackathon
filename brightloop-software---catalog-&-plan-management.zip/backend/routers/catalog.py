"""
Customer Catalog Router for Brightloop Software.

Provides authenticated subscribers and customers with a read-only view of
active products, brand variants, and subscription plans.

Security Enforcement:
1. Role check ensures caller is an authenticated customer or admin.
2. Filter criteria restricts queries to `Product.is_active == True`, guaranteeing
   archived products are completely excluded.
3. Response model `CustomerProductResponse` strips `cost_price` completely at
   the serialization boundary.
"""

from datetime import date
from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session, joinedload

from ..auth import AuthenticatedUser, require_customer_or_admin
from ..database import get_db
from ..models import BillingFrequency, Plan, Product, ProductVariant
from ..schemas import CustomerProductResponse

router = APIRouter(
    prefix="/catalog",
    tags=["Customer Catalog (Read-Only)"],
    dependencies=[Depends(require_customer_or_admin)]
)


@router.get(
    "",
    response_model=List[CustomerProductResponse],
    summary="Retrieve customer-facing catalog",
    description=(
        "Returns active subscription products, brand variants, and plans. "
        "Strictly filters out internal cost prices and archived items."
    )
)
def get_customer_catalog(
    is_addon: Optional[bool] = Query(None, description="Filter by add-on flag (True for modular add-ons)"),
    billing_frequency: Optional[BillingFrequency] = Query(None, description="Filter products offering this cadence"),
    search: Optional[str] = Query(None, description="Search products by title or description keyword"),
    db: Session = Depends(get_db),
    current_user: AuthenticatedUser = Depends(require_customer_or_admin)
) -> List[Product]:
    """
    Customer Catalog Fetch:
    - Filters: is_active == True (Never reveals soft-deleted/archived products)
    - Response: CustomerProductResponse (Pydantic model omits cost_price)
    - Relationships: Eagerly loads active variants and active plans
    """
    today = date.today()
    
    # Query only active products
    query = (
        db.query(Product)
        .filter(Product.is_active.is_(True))
        .options(
            joinedload(Product.variants),
            joinedload(Product.plans)
        )
    )

    if is_addon is not None:
        query = query.filter(Product.is_addon == is_addon)

    if search:
        search_pattern = f"%{search.strip()}%"
        query = query.filter(
            (Product.name.ilike(search_pattern)) | 
            (Product.notes.ilike(search_pattern))
        )

    products = query.order_by(Product.id.asc()).all()

    # Filter out inactive variants and plans or expired plans from the active products
    filtered_products = []
    for product in products:
        # Filter variants to only active ones
        active_variants = [v for v in product.variants if v.is_active]
        
        # Filter plans: must be active and within availability dates if defined
        active_plans = [
            p for p in product.plans
            if p.is_active and
            (p.available_from is None or p.available_from <= today) and
            (p.available_until is None or p.available_until >= today)
        ]

        if billing_frequency is not None:
            active_plans = [p for p in active_plans if p.billing_frequency == billing_frequency]
            # If frequency filter requested and no matching plans, skip this product
            if not active_plans:
                continue

        # Attach filtered active sub-collections to product instance for serialization
        product.variants = active_variants
        product.plans = active_plans
        filtered_products.append(product)

    return filtered_products
