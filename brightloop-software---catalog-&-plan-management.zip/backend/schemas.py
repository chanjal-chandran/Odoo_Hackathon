"""
Pydantic Schemas for Brightloop Software Catalog and Plan Management.

Key Security & Serialization Design:
1. CustomerProductResponse strictly omits `cost_price` and internal margins,
   exposing only public catalog fields and active relationships.
2. AdminProductResponse includes `cost_price`, calculated margin percentages,
   and audit timestamps for business operations.
"""

from datetime import date, datetime
from typing import List, Optional
from pydantic import BaseModel, ConfigDict, Field, computed_field

from .models import BillingFrequency


# -----------------------------------------------------------------------------
# Variant Schemas
# -----------------------------------------------------------------------------
class VariantBase(BaseModel):
    variant_name: str = Field(..., description="Variant title, e.g. 'Brand Edition Alpha'")
    brand: Optional[str] = Field(None, description="Brand name if applicable, e.g. 'Brightloop Elite'")
    price_modifier: float = Field(
        0.0,
        description="Amount added to base product sales price (e.g. +560.00 for premium brand choice)"
    )
    sku: Optional[str] = Field(None, description="Stock keeping unit or variant identifier")
    is_active: bool = Field(True, description="Whether variant is active and selectable")


class VariantCreate(VariantBase):
    product_id: int = Field(..., description="Associated product ID")


class VariantUpdate(BaseModel):
    variant_name: Optional[str] = None
    brand: Optional[str] = None
    price_modifier: Optional[float] = None
    sku: Optional[str] = None
    is_active: Optional[bool] = None


class VariantResponse(VariantBase):
    id: int
    product_id: int

    model_config = ConfigDict(from_attributes=True)


# -----------------------------------------------------------------------------
# Plan Schemas
# -----------------------------------------------------------------------------
class PlanBase(BaseModel):
    name: str = Field(..., description="Plan title, e.g. 'Enterprise Monthly'")
    billing_frequency: BillingFrequency = Field(
        BillingFrequency.MONTHLY,
        description="Billing cycle cadence: daily, weekly, monthly, or yearly"
    )
    price: float = Field(..., ge=0, description="Recurring price for the billing cycle")
    minimum_quantity: int = Field(1, ge=1, description="Minimum quantity commitment required")
    available_from: Optional[date] = Field(None, description="Start date of plan offering")
    available_until: Optional[date] = Field(None, description="End date / sunset date of plan offering")
    
    # Subscription Lifecycle Rules
    allow_auto_close: bool = Field(False, description="Auto-close subscription at end of term")
    allow_early_closure: bool = Field(True, description="Customer early termination permitted")
    allow_pause: bool = Field(True, description="Customer can pause subscription renewals")
    allow_renew: bool = Field(True, description="Auto-renew at period end")
    is_active: bool = Field(True, description="Plan active status")


class PlanCreate(PlanBase):
    product_id: int = Field(..., description="Parent product ID")


class PlanUpdate(BaseModel):
    name: Optional[str] = None
    billing_frequency: Optional[BillingFrequency] = None
    price: Optional[float] = None
    minimum_quantity: Optional[int] = None
    available_from: Optional[date] = None
    available_until: Optional[date] = None
    allow_auto_close: Optional[bool] = None
    allow_early_closure: Optional[bool] = None
    allow_pause: Optional[bool] = None
    allow_renew: Optional[bool] = None
    is_active: Optional[bool] = None


class PlanResponse(PlanBase):
    id: int
    product_id: int

    model_config = ConfigDict(from_attributes=True)


# -----------------------------------------------------------------------------
# Customer Catalog Schemas (READ-ONLY, SENSITIVE DATA REDACTED)
# -----------------------------------------------------------------------------
class CustomerProductResponse(BaseModel):
    """
    Public / Customer facing product schema.
    
    SECURITY INVARIANT:
    `cost_price` is deliberately omitted from this model and will never be
    serialized in customer responses. Only active variants and plans are exposed.
    """
    id: int
    name: str
    type: str
    sales_price: float
    notes: Optional[str] = None
    is_addon: bool
    variants: List[VariantResponse] = []
    plans: List[PlanResponse] = []

    model_config = ConfigDict(from_attributes=True)


# -----------------------------------------------------------------------------
# Admin Management Schemas (FULL CRUD & FINANCIAL VISIBILITY)
# -----------------------------------------------------------------------------
class ProductCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    type: str = Field("subscription", max_length=100)
    sales_price: float = Field(..., ge=0, description="Base sales price to customers")
    cost_price: float = Field(..., ge=0, description="Internal unit/COGS cost price")
    notes: Optional[str] = None
    is_addon: bool = Field(False, description="True if customers can toggle on/off as add-on")
    is_active: bool = Field(True, description="Active status; false represents soft-deleted/archived")


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    type: Optional[str] = None
    sales_price: Optional[float] = None
    cost_price: Optional[float] = None
    notes: Optional[str] = None
    is_addon: Optional[bool] = None
    is_active: Optional[bool] = None


class AdminProductResponse(BaseModel):
    """
    Admin-only product schema. Includes full internal cost accounting,
    gross margin calculation, and soft-delete audit status.
    """
    id: int
    name: str
    type: str
    sales_price: float
    cost_price: float
    notes: Optional[str] = None
    is_addon: bool
    is_active: bool
    created_at: datetime
    updated_at: datetime
    variants: List[VariantResponse] = []
    plans: List[PlanResponse] = []

    model_config = ConfigDict(from_attributes=True)

    @computed_field
    @property
    def gross_margin(self) -> float:
        """Calculates internal gross margin dollar amount: sales_price - cost_price."""
        return round(self.sales_price - self.cost_price, 2)

    @computed_field
    @property
    def gross_margin_percent(self) -> float:
        """Calculates internal gross margin percentage."""
        if self.sales_price <= 0:
            return 0.0
        return round(((self.sales_price - self.cost_price) / self.sales_price) * 100, 2)


class ArchiveResponse(BaseModel):
    """Response returned upon soft-deleting/archiving a product."""
    product_id: int
    name: str
    is_active: bool
    message: str
