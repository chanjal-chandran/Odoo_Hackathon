"""
Flask Blueprint: Customer Catalog Router for Brightloop Software.

Provides authenticated subscribers and customers with a read-only view of
active products, brand variants, and subscription plans.

Security Enforcement:
1. Role check ensures caller is an authenticated customer or admin.
2. Filter criteria restricts queries to `Product.is_active == True`, guaranteeing
   archived products are completely excluded.
3. Response model `CustomerProductResponse` strips `cost_price` completely at
   the Pydantic serialization boundary.
"""

from datetime import date
from flask import Blueprint, jsonify, request
from sqlalchemy.orm import joinedload

from ..auth import require_customer_or_admin
from ..database import db_session
from ..models import BillingFrequency, Product
from ..schemas import CustomerProductResponse

catalog_bp = Blueprint("catalog", __name__, url_prefix="/catalog")


@catalog_bp.route("", methods=["GET"])
@require_customer_or_admin
def get_customer_catalog():
    """
    Customer Catalog Fetch:
    - Filters: is_active == True (Never reveals soft-deleted/archived products)
    - Response: CustomerProductResponse (Pydantic model omits cost_price)
    - Relationships: Eagerly loads active variants and active plans
    """
    today = date.today()
    
    # Query parameters
    is_addon_param = request.args.get("is_addon")
    billing_freq_param = request.args.get("billing_frequency")
    search_param = request.args.get("search")

    query = (
        db_session.query(Product)
        .filter(Product.is_active.is_(True))
        .options(
            joinedload(Product.variants),
            joinedload(Product.plans)
        )
    )

    if is_addon_param is not None:
        is_addon_val = is_addon_param.lower() in ("true", "1")
        query = query.filter(Product.is_addon == is_addon_val)

    if search_param:
        pattern = f"%{search_param.strip()}%"
        query = query.filter(
            (Product.name.ilike(pattern)) | 
            (Product.notes.ilike(pattern))
        )

    products = query.order_by(Product.id.asc()).all()

    filtered_payload = []
    for product in products:
        # Filter active variants only
        active_variants = [v for v in product.variants if v.is_active]
        
        # Filter active plans within availability window
        active_plans = [
            p for p in product.plans
            if p.is_active and
            (p.available_from is None or p.available_from <= today) and
            (p.available_until is None or p.available_until >= today)
        ]

        if billing_freq_param:
            active_plans = [
                p for p in active_plans
                if p.billing_frequency.value == billing_freq_param or p.billing_frequency == billing_freq_param
            ]
            if not active_plans:
                continue

        product.variants = active_variants
        product.plans = active_plans

        # STRICT PYDANTIC SERIALIZATION: cost_price is omitted in CustomerProductResponse!
        serialized = CustomerProductResponse.model_validate(product).model_dump()
        filtered_payload.append(serialized)

    return jsonify(filtered_payload), 200
