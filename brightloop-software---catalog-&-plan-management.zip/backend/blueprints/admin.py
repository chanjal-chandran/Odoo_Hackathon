"""
Flask Blueprint: Admin Product & Plan Management for Brightloop Software.

Features:
1. Full CRUD for Products, Brand Variants, and Plans.
2. Financial transparency: Exposes cost_price and calculates margin performance.
3. Archiving Service (Soft Delete): Toggles `is_active = False` on products to
   preserve referential integrity for historical subscriptions, reporting,
   and past invoices without orphan errors.
4. Strict access control: Guarded by `@require_admin`.
"""

from flask import Blueprint, jsonify, request
from pydantic import ValidationError
from sqlalchemy.orm import joinedload

from ..auth import require_admin
from ..database import db_session
from ..models import Plan, Product, ProductVariant
from ..schemas import (
    AdminProductResponse,
    ArchiveResponse,
    PlanCreate,
    PlanResponse,
    PlanUpdate,
    ProductCreate,
    ProductUpdate,
    VariantCreate,
    VariantResponse,
    VariantUpdate,
)

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")


# -----------------------------------------------------------------------------
# Product Operations (CRUD + Soft Delete)
# -----------------------------------------------------------------------------

@admin_bp.route("/products", methods=["GET"])
@require_admin
def list_admin_products():
    """Returns all products including cost prices, margins, and soft-deleted items."""
    include_archived = request.args.get("include_archived", "true").lower() in ("true", "1")
    
    query = db_session.query(Product).options(
        joinedload(Product.variants),
        joinedload(Product.plans)
    )
    if not include_archived:
        query = query.filter(Product.is_active.is_(True))

    products = query.order_by(Product.id.asc()).all()
    serialized = [AdminProductResponse.model_validate(p).model_dump() for p in products]
    return jsonify(serialized), 200


@admin_bp.route("/products", methods=["POST"])
@require_admin
def create_product():
    """Creates a new subscription product with sales price and restricted cost price."""
    json_data = request.get_json(silent=True) or {}
    try:
        payload = ProductCreate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    new_product = Product(
        name=payload.name,
        type=payload.type,
        sales_price=payload.sales_price,
        cost_price=payload.cost_price,
        notes=payload.notes,
        is_addon=payload.is_addon,
        is_active=payload.is_active
    )
    db_session.add(new_product)
    db_session.commit()
    db_session.refresh(new_product)

    return jsonify(AdminProductResponse.model_validate(new_product).model_dump()), 201


@admin_bp.route("/products/<int:product_id>", methods=["GET"])
@require_admin
def get_product(product_id: int):
    product = (
        db_session.query(Product)
        .options(joinedload(Product.variants), joinedload(Product.plans))
        .filter(Product.id == product_id)
        .first()
    )
    if not product:
        return jsonify({"detail": f"Product with id {product_id} not found."}), 404
    return jsonify(AdminProductResponse.model_validate(product).model_dump()), 200


@admin_bp.route("/products/<int:product_id>", methods=["PUT"])
@require_admin
def update_product(product_id: int):
    product = db_session.query(Product).filter(Product.id == product_id).first()
    if not product:
        return jsonify({"detail": f"Product with id {product_id} not found."}), 404

    json_data = request.get_json(silent=True) or {}
    try:
        payload = ProductUpdate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    update_dict = payload.model_dump(exclude_unset=True)
    for field, value in update_dict.items():
        setattr(product, field, value)

    db_session.commit()
    db_session.refresh(product)
    return jsonify(AdminProductResponse.model_validate(product).model_dump()), 200


@admin_bp.route("/products/<int:product_id>/archive", methods=["DELETE"])
@require_admin
def archive_product(product_id: int):
    """
    Soft-Delete (Archive Service):
    Toggles `is_active` to False. Soft deleting preserves relational integrity
    so that past subscription billing cycles, historical invoices, and audit logs
    remain completely intact without orphan errors.
    """
    product = db_session.query(Product).filter(Product.id == product_id).first()
    if not product:
        return jsonify({"detail": f"Product with id {product_id} not found."}), 404

    product.is_active = False
    db_session.commit()

    response = ArchiveResponse(
        product_id=product.id,
        name=product.name,
        is_active=False,
        message=(
            f"Product '{product.name}' successfully archived. "
            f"Historical subscriptions, invoices, and billing records remain fully intact."
        )
    )
    return jsonify(response.model_dump()), 200


@admin_bp.route("/products/<int:product_id>/restore", methods=["POST"])
@require_admin
def restore_product(product_id: int):
    product = db_session.query(Product).filter(Product.id == product_id).first()
    if not product:
        return jsonify({"detail": f"Product with id {product_id} not found."}), 404

    product.is_active = True
    db_session.commit()

    response = ArchiveResponse(
        product_id=product.id,
        name=product.name,
        is_active=True,
        message=f"Product '{product.name}' is now active and visible in the customer catalog."
    )
    return jsonify(response.model_dump()), 200


# -----------------------------------------------------------------------------
# Product Variant Management (Relational Brand Choices & Modifiers)
# -----------------------------------------------------------------------------

@admin_bp.route("/variants", methods=["POST"])
@require_admin
def create_variant():
    """
    Adds a variant with a price_modifier column (e.g., adding +560 to base price for brand choice).
    """
    json_data = request.get_json(silent=True) or {}
    try:
        payload = VariantCreate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    product = db_session.query(Product).filter(Product.id == payload.product_id).first()
    if not product:
        return jsonify({"detail": f"Target product {payload.product_id} does not exist."}), 404

    variant = ProductVariant(
        product_id=payload.product_id,
        variant_name=payload.variant_name,
        brand=payload.brand,
        price_modifier=payload.price_modifier,
        sku=payload.sku,
        is_active=payload.is_active
    )
    db_session.add(variant)
    db_session.commit()
    db_session.refresh(variant)

    return jsonify(VariantResponse.model_validate(variant).model_dump()), 201


@admin_bp.route("/variants/<int:variant_id>", methods=["PUT"])
@require_admin
def update_variant(variant_id: int):
    variant = db_session.query(ProductVariant).filter(ProductVariant.id == variant_id).first()
    if not variant:
        return jsonify({"detail": f"Variant with id {variant_id} not found."}), 404

    json_data = request.get_json(silent=True) or {}
    try:
        payload = VariantUpdate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(variant, field, value)

    db_session.commit()
    db_session.refresh(variant)
    return jsonify(VariantResponse.model_validate(variant).model_dump()), 200


# -----------------------------------------------------------------------------
# Plan Management (Billing Cadence & Lifecycle Rules)
# -----------------------------------------------------------------------------

@admin_bp.route("/plans", methods=["POST"])
@require_admin
def create_plan():
    """
    Creates a subscription plan linked to a product with frequency, minimum quantity,
    availability window, and lifecycle flags (auto-close, early closure, pause, renew).
    """
    json_data = request.get_json(silent=True) or {}
    try:
        payload = PlanCreate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    product = db_session.query(Product).filter(Product.id == payload.product_id).first()
    if not product:
        return jsonify({"detail": f"Parent product {payload.product_id} does not exist."}), 404

    if payload.available_from and payload.available_until:
        if payload.available_from > payload.available_until:
            return jsonify({"detail": "available_from date must precede available_until date."}), 400

    plan = Plan(
        product_id=payload.product_id,
        name=payload.name,
        billing_frequency=payload.billing_frequency,
        price=payload.price,
        minimum_quantity=payload.minimum_quantity,
        available_from=payload.available_from,
        available_until=payload.available_until,
        allow_auto_close=payload.allow_auto_close,
        allow_early_closure=payload.allow_early_closure,
        allow_pause=payload.allow_pause,
        allow_renew=payload.allow_renew,
        is_active=payload.is_active
    )
    db_session.add(plan)
    db_session.commit()
    db_session.refresh(plan)

    return jsonify(PlanResponse.model_validate(plan).model_dump()), 201


@admin_bp.route("/plans/<int:plan_id>", methods=["PUT"])
@require_admin
def update_plan(plan_id: int):
    plan = db_session.query(Plan).filter(Plan.id == plan_id).first()
    if not plan:
        return jsonify({"detail": f"Plan with id {plan_id} not found."}), 404

    json_data = request.get_json(silent=True) or {}
    try:
        payload = PlanUpdate.model_validate(json_data)
    except ValidationError as err:
        return jsonify({"detail": err.errors()}), 422

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(plan, field, value)

    db_session.commit()
    db_session.refresh(plan)
    return jsonify(PlanResponse.model_validate(plan).model_dump()), 200
