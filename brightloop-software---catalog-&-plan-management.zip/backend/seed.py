"""
Database Seed Script for Brightloop Software Catalog & Plan Management.
Pre-populates demonstration data including variants with +560 brand price modifiers,
various billing frequencies (daily, weekly, monthly, yearly), lifecycle flags, and archived products.
"""

from datetime import date, timedelta
from .database import Base, SessionLocal, engine
from .models import BillingFrequency, Plan, Product, ProductVariant


def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # Skip if already seeded
    if db.query(Product).first():
        db.close()
        return

    today = date.today()

    # 1. Flagship Core Subscription Product
    core_product = Product(
        name="Brightloop Unified Subscription Engine",
        type="subscription",
        sales_price=1200.00,
        cost_price=380.00,  # Sensitive internal COGS
        notes="Core recurring billing and customer lifecycle orchestration platform.",
        is_addon=False,
        is_active=True
    )
    db.add(core_product)
    db.flush()

    # Variants: Demonstrating specific brand choices and price modifiers (+560 example)
    v1_standard = ProductVariant(
        product_id=core_product.id,
        variant_name="Standard Multi-Tenant Cloud",
        brand="Brightloop Base",
        price_modifier=0.00,
        sku="BL-CORE-STD-01",
        is_active=True
    )
    # The prompt's exact requirement: adding 560 to base price for a specific brand choice
    v2_elite = ProductVariant(
        product_id=core_product.id,
        variant_name="Dedicated Sovereign Cloud",
        brand="Brightloop Elite Enterprise",
        price_modifier=560.00,  # +560.00 for Elite Enterprise brand choice!
        sku="BL-CORE-ELITE-560",
        is_active=True
    )
    v3_partner = ProductVariant(
        product_id=core_product.id,
        variant_name="White-Label Co-Branded Portal",
        brand="Partner Choice Tier",
        price_modifier=290.00,
        sku="BL-CORE-PARTNER-290",
        is_active=True
    )
    db.add_all([v1_standard, v2_elite, v3_partner])

    # Plans with various billing frequencies & lifecycle rules
    p1_monthly = Plan(
        product_id=core_product.id,
        name="Monthly Flexible Subscription",
        billing_frequency=BillingFrequency.MONTHLY,
        price=1200.00,
        minimum_quantity=1,
        available_from=today - timedelta(days=30),
        available_until=today + timedelta(days=365),
        allow_auto_close=False,     # Continues indefinitely
        allow_early_closure=True,    # Subscriber may cancel early
        allow_pause=True,            # Billing cycles can be paused
        allow_renew=True,            # Auto-renews every 30 days
        is_active=True
    )
    p2_annual = Plan(
        product_id=core_product.id,
        name="Annual Growth Commitment",
        billing_frequency=BillingFrequency.YEARLY,
        price=11520.00,  # 20% discount on yearly commitment
        minimum_quantity=1,
        available_from=today - timedelta(days=60),
        available_until=today + timedelta(days=365),
        allow_auto_close=False,
        allow_early_closure=False,   # 1-year contract commitment
        allow_pause=True,
        allow_renew=True,
        is_active=True
    )
    p3_weekly = Plan(
        product_id=core_product.id,
        name="Weekly Rapid Sandbox Pilot",
        billing_frequency=BillingFrequency.WEEKLY,
        price=320.00,
        minimum_quantity=1,
        available_from=today - timedelta(days=15),
        available_until=today + timedelta(days=90),
        allow_auto_close=True,      # Auto-terminates after pilot period
        allow_early_closure=True,
        allow_pause=False,          # Fast pilot, no pausing
        allow_renew=False,
        is_active=True
    )
    db.add_all([p1_monthly, p2_annual, p3_weekly])

    # 2. Add-on Product: AI Churn & Retention Predictor
    addon_ai = Product(
        name="AI Churn & Predictive Retention Engine",
        type="service",
        sales_price=450.00,
        cost_price=125.00,  # Sensitive internal model inferencing cost
        notes="Machine learning model detecting churn probability and automated win-back workflows.",
        is_addon=True,      # Customer can toggle this on/off
        is_active=True
    )
    db.add(addon_ai)
    db.flush()

    v_ai_standard = ProductVariant(
        product_id=addon_ai.id,
        variant_name="Real-time Inference Standard",
        brand="Brightloop AI",
        price_modifier=0.00,
        sku="BL-ADDON-AI-01",
        is_active=True
    )
    v_ai_custom = ProductVariant(
        product_id=addon_ai.id,
        variant_name="Custom Fine-Tuned Weights",
        brand="Brightloop AI Custom",
        price_modifier=350.00,
        sku="BL-ADDON-AI-CUSTOM",
        is_active=True
    )
    db.add_all([v_ai_standard, v_ai_custom])

    p_ai_monthly = Plan(
        product_id=addon_ai.id,
        name="Monthly Add-on Rate",
        billing_frequency=BillingFrequency.MONTHLY,
        price=450.00,
        minimum_quantity=1,
        available_from=today - timedelta(days=90),
        available_until=None,
        allow_auto_close=False,
        allow_early_closure=True,
        allow_pause=True,
        allow_renew=True,
        is_active=True
    )
    p_ai_daily = Plan(
        product_id=addon_ai.id,
        name="High-Volume Daily Metering",
        billing_frequency=BillingFrequency.DAILY,
        price=18.50,
        minimum_quantity=5,  # Min 5 seats
        available_from=today - timedelta(days=30),
        available_until=None,
        allow_auto_close=False,
        allow_early_closure=True,
        allow_pause=True,
        allow_renew=True,
        is_active=True
    )
    db.add_all([p_ai_monthly, p_ai_daily])

    # 3. Add-on Product: Global Tax Compliance Suite
    addon_tax = Product(
        name="Automated Multi-Jurisdiction Tax Suite",
        type="service",
        sales_price=290.00,
        cost_price=70.00,
        notes="Automated VAT, GST, and US Sales tax calculation and remittance filing.",
        is_addon=True,
        is_active=True
    )
    db.add(addon_tax)
    db.flush()

    p_tax_monthly = Plan(
        product_id=addon_tax.id,
        name="Monthly Standard Filing",
        billing_frequency=BillingFrequency.MONTHLY,
        price=290.00,
        minimum_quantity=1,
        available_from=today - timedelta(days=60),
        available_until=None,
        allow_auto_close=False,
        allow_early_closure=True,
        allow_pause=True,
        allow_renew=True,
        is_active=True
    )
    db.add(p_tax_monthly)

    # 4. Soft-Deleted / Archived Product: Preserves historical subscriptions & invoices!
    archived_legacy = Product(
        name="Legacy Billing Connector v1 (Sunset)",
        type="subscription",
        sales_price=750.00,
        cost_price=520.00,
        notes="Deprecated connector. Soft-deleted to ensure past invoices and audit trails remain intact.",
        is_addon=False,
        is_active=False     # Soft-deleted / Archived!
    )
    db.add(archived_legacy)
    db.flush()

    p_legacy_plan = Plan(
        product_id=archived_legacy.id,
        name="Grandfathered Monthly",
        billing_frequency=BillingFrequency.MONTHLY,
        price=750.00,
        minimum_quantity=1,
        available_from=today - timedelta(days=700),
        available_until=today - timedelta(days=100),
        allow_auto_close=True,
        allow_early_closure=False,
        allow_pause=False,
        allow_renew=False,
        is_active=False
    )
    db.add(p_legacy_plan)

    db.commit()
    db.close()


if __name__ == "__main__":
    seed_database()
    print("Brightloop catalog database seeded successfully.")
